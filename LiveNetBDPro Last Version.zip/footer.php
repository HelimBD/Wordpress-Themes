<!--Extra Menu-->
<?php include('includes/keyword.php'); ?>
<center><img src="http://hnet.yn.lt/add/mobile-footer-ad.png"/></center>
<!--Footer Links-->
<?php include('includes/menu/footer-menu.php');?>

<div id="mainFooter">
<div id="mainfoot">	
<div class=""><div class="switch_pc"><font color="white"><?php echo do_shortcode('[show_theme_switch_link]'); ?> </font>
</div> Theme Developed By: <a href="https://facebook.com/helim.rana12"><font color="white" style="font-size: 15px;">Helim Hasan Akash</font></a><br><div class="switch_pc">
Copright © LiveNetBD.Ga (2010-<?php echo date("Y") ?>) ® All Rights Reserved</div><br>
</div>



<!-- BEGIN: Powered by Supercounters.com -->
<center><script type="text/javascript" src="//widget.supercounters.com/ssl/online_i.js"></script><script type="text/javascript">sc_online_i(1466602,"ffffff","e61c1c");</script><br><noscript><a href="http://www.supercounters.com/">Free Online Counter</a></noscript>
</center>
<!-- END: Powered by Supercounters.com -->
</div>
</div>
<div class="clear"></div>

<script>            
	jQuery(document).ready(function() {
		var offset = 220;
		var duration = 500;
		jQuery(window).scroll(function() {
			if (jQuery(this).scrollTop() > offset) {
				jQuery('.crunchify-top').fadeIn(duration);
			} else {
				jQuery('.crunchify-top').fadeOut(duration);
			}
		});
 
		jQuery('.crunchify-top').click(function(event) {
			event.preventDefault();
			jQuery('html, body').animate({scrollTop: 0}, duration);
			return false;
		})
	});
</script>
<script>
jQuery(document).ready(function () {
	function saveTextAsFile() {
		var textToWrite = document.getElementById("content").value;
		var textFileAsBlob = new Blob([textToWrite], { type: 'text/plain' });
		var fileNameToSaveAs = "code.txt";
		var downloadLink = document.createElement("a");
		
		downloadLink.download = fileNameToSaveAs;
		downloadLink.innerHTML = "My Hidden Link";
		window.URL = window.URL || window.webkitURL;
		downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
		downloadLink.onclick = destroyClickedElement;
		downloadLink.style.display = "none";
		document.body.appendChild(downloadLink);
		downloadLink.click();
    }
	
	function destroyClickedElement(event) {
		// remove the link from the DOM
		document.body.removeChild(event.target);
    }
	
	jQuery("#download").click(function (e) {
		e.preventDefault();
		saveTextAsFile();
       });
 });  
</script>



<script>
jQuery(document).ready(function () {
	function saveTextAsFile() {
		var textToWrite = document.getElementById("content").value;
		var textFileAsBlob = new Blob([textToWrite], { type: 'text/plain' });
		var fileNameToSaveAs = "code.txt";
		var downloadLink = document.createElement("a");
		
		downloadLink.download = fileNameToSaveAs;
		downloadLink.innerHTML = "My Hidden Link";
		window.URL = window.URL || window.webkitURL;
		downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
		downloadLink.onclick = destroyClickedElement;
		downloadLink.style.display = "none";
		document.body.appendChild(downloadLink);
		downloadLink.click();
    }
	
	function destroyClickedElement(event) {
		// remove the link from the DOM
		document.body.removeChild(event.target);
    }
	
	jQuery("#download").click(function (e) {
		e.preventDefault();
		saveTextAsFile();
       });
 });  
</script>

</body>
</html>