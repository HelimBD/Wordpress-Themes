<?php get_header(); ?>

<div id="post-content">
<?php if(have_posts()) : ?> <?php while(have_posts()) : the_post(); ?>

<div id="block">
    <div id="post-menu">

<h1><?php the_title(); ?></h1>

<?php include('includes/extra/post-details.php');?>
<div class="pc_content">
<div class="textp">
<div class="post-contents">
<div class=""><?php the_content(''); ?></div>
<?php $post_link	= wp_get_shortlink();
		$post_title = wp_strip_all_tags( get_the_title() );
		$protocol	= is_ssl() ? 'https' : 'http'; ?>
</div></div></div>

<div class="m_content">
<div class="textp">
<div class="post-contents">
<p><?php the_content(''); ?></p>
<?php $post_link	= wp_get_shortlink();
		$post_title = wp_strip_all_tags( get_the_title() );
		$protocol	= is_ssl() ? 'https' : 'http'; ?>
</div></div></div><?php wpfp_link(); ?>
<div id="padding"><?php include('includes/share-button.php');?></div>

</div></div>
<table style="width:100%">
  <tr>
    <th align="left" style="width:50%"><?php $post_link = get_permalink(); echo do_shortcode('[report_pg var="action" sub="'.$post_link.'"]'); ?></th>
    
   
    
    <th align="right" style="width:50%"><?php $user_id = get_the_author_meta('ID'); $cr_id = get_current_user_id();
	if ( (is_user_logged_in() && $user_id == $cr_id ) || current_user_can('administrator') || current_user_can('editor')){
	global $wpdb;
	$options1 = get_option('ln_options1'); 
	$url5 = $options1["plink_dash"];  ?>
	<div class="edit_post"><a href="<?php echo $url5.'?page=edit_post&post_id='.get_the_ID(); ?>"><?php _e('Edit'); ?></a></div>
<?php } ?></th>
  </tr>
</table>

<div id="block">
<div class="tagcloud"><?php
$before = '';
$seperator = ''; // blank instead of comma
$after = '';

the_tags( $before, $seperator, $after );
?></div></div></div>
<div id="post-content">
<div id="block">
<div id="post-menu">
<h1>About Author</h1>
<table width="100%" style="background: #fff; padding: 6px; margin:0px;"><tbody><tr> <td width="10%" valign="top" class="user-avatar"><?php echo get_avatar( get_the_author_meta( 'ID' ), 60 ); ?></td><td class="l" valign="top">
<span> <font size="4"><?php the_author_posts_link(); ?></font> </span><br>
<span><?php global $post;
if ( user_can( $post->post_author, 'administrator' ) ) {
echo '<font color="green">Administrator</font>';
} 
elseif ( user_can( $post->post_author, 'editor' ) ) {
echo '<font color="grenn">Administrator</font>';
}
elseif ( user_can( $post->post_author, 'author' ) ) {
echo '<font color="blue">Author</font>';
}
elseif ( user_can( $post->post_author, 'contributor' ) ) {
echo '<font color="skyblue">Contributor</font>';
}
elseif ( user_can( $post->post_author, 'subscriber' ) ) {
echo '<font color="deeppink">Subscriber</font>';}
else {
echo '<strong>Guest</strong>';
}?></span><br>
<span><font color="red"> Total Post: [<?php the_author_posts (); ?>]</font></span><br>
<span style="font-size: 13px;"> <font color="black"><?php the_author_meta('user_description'); ?></font></span></td></tr></tbody></table></div></div></div>
<center><img src="http://hnet.yn.lt/add/homepage-ad.png"/></center>
<style>.textp {
 white-space: pre-wrap;       /* css-3 */
 white-space: -moz-pre-wrap;  /* Mozilla, since 1999 */
 white-space: -pre-wrap;      /* Opera 4-6 */
 white-space: -o-pre-wrap;    /* Opera 7 */
 word-wrap: break-word;       /* Internet Explorer 5.5+ */
}
p {
    font-size: 1.3em;}
    
    .paginght {margin: 0px; font-size: 0px; }
</style>


<!--Comment Template-->
<?php comments_template( '', true ); ?></div></div>

<?php endwhile; ?>
<?php endif; ?>
	
<?php setPostViews(get_the_ID()); ?> 
<div id="post-content">
<?php get_template_part('includes/post/related-post'); ?>
</div>
<?php get_template_part(sidebar);?> 
<?php get_footer(); ?>