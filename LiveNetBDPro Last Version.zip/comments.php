<font color="black"><?php

// Do not delete these lines
	if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');

	if ( post_password_required() ) { ?>

<p class="nocomments">Password protected.</p>
<?php
		return;
	}
?>
<div id="block">
<div id="post-menu">
<!-- You can start editing here. -->
<?php if ( have_comments() ) : ?>
<div id="comments"><h1><?php comments_number('No Responses', '1 Responses', '% Responses');?> to “<?php the_title(); ?>”</h1></div>

<div class="navigation">
<div class="alignleft"></div>
<div class="alignright"></div>
</div>

<div class="navigation">
<div class="previous">
<?php previous_comments_link() ?>
</div>
<div class="next"> 
<?php next_comments_link() ?>
</div>
</div>

<ol class="commentlist">
<?php wp_list_comments(); ?>
</ol>

<div class="navigation">
<div class="previous">
<?php previous_comments_link() ?>
</div>
<div class="previous">
<?php next_comments_link() ?>
</div>
</div>

<?php else : // this is displayed if there are no comments so far ?>
<?php if ('open' == $post->comment_status) : ?>
<!-- If comments are open, but there are no comments. -->
<?php else : // comments are closed ?>
<!-- If comments are closed. -->
<p class="notice">Comment has been closed!</p>
<?php endif; ?>
<?php endif; ?>

<?php if ('open' == $post->comment_status) : ?>

<div class="navigation">
<div class="alignleft"></div>
<div class="alignright"></div>
</div>

<div id="respond">

<h1>Leave a Reply</h1>

<div class="cancel-comment-reply"><small>
<?php cancel_comment_reply_link(); ?>
</small></div>

<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
<p class="notice"><?php print 'You Must be'; ?> <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php echo urlencode(get_permalink()); ?>"><?php print 'Login'; ?></a> or <a target="_blink" href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=register"><?php print 'Register'; ?></a> <?php print 'to Submit Comment'; ?>.</p>
<?php else : ?>
<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
      <?php if ( $user_ID ) : ?>
<p class="notice"><?php print 'Logged'; ?> › <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a> › <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="Log Out From This Account"><?php print 'Log Out'; ?> »</a>
</p>
<?php else : ?>

<p class="line"><label for="author"><font color="#444">Your Name:</font> <small><font color="red"><?php if ($req) echo "(Required)"; ?></font></small></label><br/><input type="text" class="inp_text" name="author" id="author" value="<?php echo $comment_author; ?>" size="22" tabindex="1" />
</p>

<p class="line"><label for="email"><font color=#444">E-Mail Address:</font> <small><font color="red"><?php if ($req) echo " (Required)"; ?></font></small></label><br/><input type="text" class="inp_text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="22" tabindex="2" />
</p>

<p class="line"><label for="url"><font color=#444">Website:</font> <small><font color="blue"><?php if ($req) echo "(Optional)"; ?></font></small></label><br/><input type="text" class="inp_text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="22" tabindex="3" />
</p>
<?php endif; ?>
<!--<p><small><strong>XHTML:</strong> You can use these tags: <code><?php echo allowed_tags(); ?></code></small></p>-->

<p class="line"><font color=#444">Comment:</font> <small><font color="green">(Write Something About This Post..)</font></small><br/><textarea name="comment" class="inp_textarea"></textarea></p>

<p>
<input class="submit" name="submit" type="submit" id="submit" tabindex="5" value="Submit Comment" />
<?php comment_id_fields(); ?></p>
<?php do_action('comment_form', $post->ID); ?>
</form>
<?php endif; // If registration required and not logged in ?>
</div>
<?php endif; // if you delete this the sky will fall on your head ?>
</div></font>