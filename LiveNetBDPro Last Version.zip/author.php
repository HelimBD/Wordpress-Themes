<?php get_template_part(header); ?>
<script language="javascript">document.title="<?php the_author(); ?> | <?php bloginfo('title'); ?> "</script>
<?php $curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author));
    $user_info = get_userdata( $curauth->ID );
	$role = implode(',', $user_info->roles );
	$registered = $user_info->user_registered;
	$description = $user_info->description;
	$url = $user_info->user_url;
	$display_name = $user_info->display_name;
	$current_user = get_current_user_id();
?>
<div class="profile_cover">
<div style="display: block; float: left; position:absolute; margin-top: 40px; z-index:2;padding:1px 10px;">
<div class="propic" title="<?php the_author(); ?>" style="background: #ffffff; padding: 3px; border: 1px solid #cccccc;"><?php echo get_avatar( get_the_author_meta('email'), '75' ); ?></div>
</div></div>
<div style="clear: both;">
<div style="padding: 1px 10px; background: #EEEEEE; height: 50px;">
<div style="overflow:hidden;clear:both;float:left;padding: 4px 10px; background: #ededed; color:#505050;z-&shy;index: 2;padding-left: 110px;">
<b><?php echo $display_name; ?></b><br>
<b></b>
</div></div></div>
<?php if( $curauth->ID == $current_user ){ ?>
	<div class="edit_post"><a href="
<?php echo home_url(); ?>/wp-admin/profile.php">Edit Profile</a></div>
<?php } ?>

<div id="block">
<div id="post-menu">
<h1>Author Details</h1>
<div class="line"><p id="p-user-id"></p> <span>User ID: </span> <?php the_author_id(); ?></div>
<div class="line"><p id="p-user-posts"></p> <span>Total Posts:</span> <?php the_author_posts(); ?></div>
<div class="line"><p id="p-user-r-date"></p> <span>Registered:</span> <?php echo $curauth->user_registered; ?></div></div></div>


<div id="block">
<div id="post-menu">
<h1>Author Links</h1>
<div class="line"><p id="p-user-facebook"></p> <span>Facebook: </span> <a target="_blink" href="<?php echo $curauth->facebook; ?>"><?php echo $curauth->facebook; ?></a></div>
<div class="line"><p id="p-user-twitter"></p> <span>Twitter: </span> <a target="_blink" href="<?php echo $curauth->twitter; ?>"><?php echo $curauth->twitter; ?></a></div>
<div class="line"><p id="p-user-website"></p> <span>Website:</span> <a target="_blink" href="<?php echo $curauth->user_url; ?>"><?php echo $curauth->user_url; ?></a></div></div></div>


<div id="block">
<div id="post-menu">
<h1>Favorite Quotes</h1>
<div class="line"><p id="p-user-quotes"></p> <span style="font-size: 13px;"><?php echo $curauth->user_description; ?></span></div></div></div>

<div id="block">
<div id="post-menu">
<h1>Author Posts</h1>
<ul class="posts">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<li>
<?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'thumbnail' );
}
else {
	echo '<img width="150" height="150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="LiveNetBD.Ga" title="LiveNetBD.Ga" src="' . get_bloginfo( 'template_url' ) . '/images/default.png"/>';
} ?>
<div class="post_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" accesskey="<?php echo $access_key; $access_key++; ?>"><?php the_title(); ?></a></div>
<font color="#000"><p id="p-author"></p><span><?php the_author_meta( 'display_name' ); ?></span> <font color="#eeeeed">|</font><p id="p-times"></p><span><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?></span> <font color="#eeeeed">|</font> <p id="p-views"></p><span> <?php echo getPostViews(get_the_ID()); ?></span></font>
<div class="pc_content">
<div style="color: #444;" class="post-content"><?php echo wp_trim_words( get_the_content(),20, '...'); ?>
</div></div>
</li>
<?php endwhile; else: ?>
<div align="center" class="no-result"><?php _e('No Posts by This Author.'); ?></div>
<?php endif; ?>
</ul></div>
<!--Pagination-->
<?php if ($wp_query->max_num_pages > 1) get_template_part('navigation') ;?>
<div class="clearfix"></div></div>

<?php get_template_part(sidebar);?> 
<?php get_footer(); ?>