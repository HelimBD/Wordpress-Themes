<?php
/*
Template Name: Mobile Dashboard
*/
?>
<?php if ( !is_user_logged_in() ){
	wp_redirect( wp_login_url(get_permalink()));
	exit;
}else{ 

//Start Sub Page
if ($_GET['page'] == "thumbnail"){ 
    
	//Set Post Thumbnail
	if ( $_REQUEST['page'] == 'thumbnail' && isset( $_POST['submit'] ) ){
        $return_id    = $_POST['return_id'];
		$past_thumb   = get_post_thumbnail_id($return_id); 
		
	    if( isset( $_POST['my_image_upload_nonce'], $return_id ) && wp_verify_nonce( $_POST['my_image_upload_nonce'], 'my_image_upload' ) ){
	    	foreach( $_FILES as $file => $array ){
		    	if( isset($_FILES['my_image_upload']) && ($_FILES['my_image_upload']['size'] > 0) ){
		    		$arr_file_type  =  wp_check_filetype(basename($_FILES['my_image_upload']['name']));
			    	$detect_type    =  $arr_file_type['type'];
					$allowed_type   =  array('image/jpg','image/jpeg','image/gif','image/png');
					$img_info       =  getimagesize($_FILES['my_image_upload']['tmp_name']);
					$img_width      =  $img_info[0];
					$img_height     =  $img_info[1];
					$img_cnt        =  count($_FILES['my_image_upload']['name']);
					
					if( $img_cnt > 1 ){
			    		$err .= "Please select only one image";
			      	}elseif( ! in_array($detect_type, $allowed_type) ){
						$err .= "Please select a JPG, JPEG, GIF, or PNG file.";
					}
				}
			}
	    }
		
		if( $return_id ){
			if (!function_exists('wp_generate_attachment_metadata')){
                require_once(ABSPATH . "wp-admin" . '/includes/image.php');
                require_once(ABSPATH . "wp-admin" . '/includes/file.php');
                require_once(ABSPATH . "wp-admin" . '/includes/media.php');
            }
			
			if( isset($_FILES['my_image_upload']) && ($_FILES['my_image_upload']['size'] > 0) && $err == "" ){
				$attach_id = media_handle_upload( $file, $return_id );	
			}elseif( isset($_POST['rdb']) ){
				$attach_id = $_POST['rdb'];	
			}elseif( $past_thumb ){
				$attach_id = $past_thumb;	
			}else{
				$err .= "Please select a thumbnail.";
			}
		}
		
		if ( $err == "" ){
	     	// Upload file in Media directory
	        require_once(ABSPATH . "wp-admin" . '/includes/image.php');
			require_once(ABSPATH . "wp-admin" . '/includes/file.php');
			require_once(ABSPATH . "wp-admin" . '/includes/media.php');
			
			//Post save as draft and redirect url
			global $wpdb;
			$options1 = get_option('ln_options1'); 
			$url5 = $options1["plink_dash"]; 
			$redirect_ul = $url5.'?action=confirm_thumb&return_id='.$return_id.'&thumb_id='.$attach_id;
			wp_redirect( $redirect_ul );
		}
    } 
	
    // Short Urk for view Post
	$post_short	= esc_url(wp_get_shortlink( $return_id ));
	
	// Attachment ID
	$curnt_user = get_current_user_id();
	$args = array(
    	   	'post_type' => 'attachment',
			'post_status' => array('publish', 'draft', 'inherit'),
			'numberposts' => -1,
			'posts_per_page' => 20,
			'orderby' => 'menu_order ID',
			'order' => 'DESC',
			'post_mime_type' => 'image',
			'author' => $curnt_user,
		    'paged' => get_query_var('paged')
		); 
	$wp_query = new WP_Query($args);
	
	global $wpdb;
	$options1 = get_option('ln_options1'); 
	$url5 = $options1["plink_dash"]; 
	get_header(); ?>
    
	<div id="block"><div id="adnan-menu">
	    <div class="page-content">
	<ul>
		<li>Please select thumbnail to publish post.</li>
		<li>You can upload new photo to set thumbnail.</li>
		<li>From bellow media list you can also just select a a photo.</li>
		<li>Your thumbnail must be related to Post.</li>
	</ul>
	</div></div></div>
	
	    
	    
	    <div id="block">
	<div id="adnan-menu">
	
	
    	<h1>Upload new</h1>
		
	<div class="page-content">
    <div id="m_sec"> <?php if ( $err != "" ){
		echo "<div id='error_rep'>".$err."</div>";
	} ?>
	
	<?php // get post link from post
	    $return_id = isset( $_REQUEST['return_id'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['return_id'] )
	    : $_REQUEST['return_id'] ) : '';
	    $return_id = urldecode( $return_id );
		// get thumbnail 
		$past_thumb = get_post_thumbnail_id( $return_id ); 
	?>
		
   <form action="" id="primary_form" method="post" enctype="multipart/form-data">
	    <input id="my_image_upload" name="my_image_upload" type="file" multiple="false" multiple accept="image/*"/>
		
		<input type="hidden" name="page" value="thumbnail"/>	
		<input type="hidden" id="return_id" name="return_id" value="<?php echo $return_id; ?>"/>
		<?php wp_nonce_field( 'my_image_upload', 'my_image_upload_nonce' ); ?>
		<input type="submit" name="submit" class="button-primary" value="<?php _e( 'Submit', 'tie' ) ?>"/>
	</form>
	</div>
	</div></div></div>
	
<div id="block">
	
<div id="adnan-menu">
    	<h1>Select thumbnail</h1>

	
    <?php if( have_posts() ):
        echo '<div id="thumbanail-list"><ul>';
	while( have_posts() ): the_post();
	    $image_url = wp_get_attachment_url( $wp_query->ID );
		$image_id = get_image_id($image_url);
		$name = basename(get_attached_file($image_id));
		global $wpdb;
		$options1 = get_option('ln_options1'); 
		$url5 = $options1["plink_dash"]; 		?>
		 
    	<li><div class="thumb_div">
	     	<a href="<?php echo $url5.'?action=confirm_thumb&return_id='.$return_id.'&thumb_id='.$image_id.''; ?>">
	    		<?php echo wp_get_attachment_image( $image_id, 'figcaption' ); ?>
			</a>
		</div></li>
			
	<?php endwhile; echo '</ul></div>';
	  	if ($wp_query->max_num_pages > 1){ echo '<div class="pagination">'; echo '<div class="wp-pagenav">'; if(function_exists('pagenavi')) { pagenavi(); } echo '</div>'; echo "</div>";  } ?>
	<?php else: ?>
	    <p><?php _e("You doesn't have any thumbnail."); ?></p>
	<?php endif; wp_reset_query(); ?>
		
    </div>	</div>	
	
<?php }elseif ($_GET['page'] == "edit_thumb"){ 
    
	//Set Post Thumbnail
	if ( $_REQUEST['page'] == 'thumbnail' && isset( $_POST['submit'] ) ){
        $return_id    = $_POST['return_id'];
		$past_thumb   = get_post_thumbnail_id($return_id); 
		
	    if( isset( $_POST['my_image_upload_nonce'], $return_id ) && wp_verify_nonce( $_POST['my_image_upload_nonce'], 'my_image_upload' ) ){
	    	foreach( $_FILES as $file => $array ){
		    	if( isset($_FILES['my_image_upload']) && ($_FILES['my_image_upload']['size'] > 0) ){
		    		$arr_file_type  =  wp_check_filetype(basename($_FILES['my_image_upload']['name']));
			    	$detect_type    =  $arr_file_type['type'];
					$allowed_type   =  array('image/jpg','image/jpeg','image/gif','image/png');
					$img_info       =  getimagesize($_FILES['my_image_upload']['tmp_name']);
					$img_width      =  $img_info[0];
					$img_height     =  $img_info[1];
					$img_cnt        =  count($_FILES['my_image_upload']['name']);
					
					if( $img_cnt > 1 ){
			    		$err .= "Please select only one image";
			      	}elseif( ! in_array($detect_type, $allowed_type) ){
						$err .= "Please select a JPG, JPEG, GIF, or PNG file.";
					}
				}
			}
	    }
		
		if( $return_id ){
			if (!function_exists('wp_generate_attachment_metadata')){
                require_once(ABSPATH . "wp-admin" . '/includes/image.php');
                require_once(ABSPATH . "wp-admin" . '/includes/file.php');
                require_once(ABSPATH . "wp-admin" . '/includes/media.php');
            }
			
			if( isset($_FILES['my_image_upload']) && ($_FILES['my_image_upload']['size'] > 0) && $err == "" ){
				$attach_id = media_handle_upload( $file, $return_id );	
			}elseif( isset($_POST['rdb']) ){
				$attach_id = $_POST['rdb'];	
			}elseif( $past_thumb ){
				$attach_id = $past_thumb;	
			}else{
				$err .= "Please select a thumbnail.";
			}
		}
		
		if ( $err == "" ){
	     	// Upload file in Media directory
	        require_once(ABSPATH . "wp-admin" . '/includes/image.php');
			require_once(ABSPATH . "wp-admin" . '/includes/file.php');
			require_once(ABSPATH . "wp-admin" . '/includes/media.php');
			
			//Post save as draft and redirect url
			global $wpdb;
			$options1 = get_option('ln_options1'); 
			$url5 = $options1["plink_dash"]; 
			$redirect_ul = $url5.'?page=edit_post&post_id='.$return_id.'&thumb_id='.$attach_id;
			wp_redirect( $redirect_ul );
		}
    } 
	
    // Short Urk for view Post
	$post_short	= esc_url(wp_get_shortlink( $return_id ));
	
	// Attachment ID
	$curnt_user = get_current_user_id();
	$args = array(
    	   	'post_type' => 'attachment',
			'post_status' => array('publish', 'draft', 'inherit'),
			'numberposts' => -1,
			'posts_per_page' => 20,
			'orderby' => 'menu_order ID',
			'order' => 'DESC',
			'post_mime_type' => 'image',
			'author' => $curnt_user,
		    'paged' => get_query_var('paged')
		); 
	$wp_query = new WP_Query($args);
	
	global $wpdb;
	$options1 = get_option('ln_options1'); 
	$url5 = $options1["plink_dash"]; 
	get_header(); ?>
    
	<div id="block"><div id="adnan-menu">
	    <div class="page-content">
	<ul>
		<li>Please select thumbnail to publish post.</li>
		<li>You can upload new photo to set thumbnail.</li>
		<li>From bellow media list you can also just select a a photo.</li>
		<li>Your thumbnail must be related to Post.</li>
	</ul>
	</div></div></div>
	
	 <div id="block">
	<div id="adnan-menu">
    	<h1>Upload new</h1>
	<div class="page-content">
    <div id="m_sec"> <?php if ( $err != "" ){
		echo "<div id='error_rep'>".$err."</div>";
	} ?>
	
	<?php // get post link from post
	    $return_id = isset( $_REQUEST['return_id'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['return_id'] )
	    : $_REQUEST['return_id'] ) : '';
	    $return_id = urldecode( $return_id );
		// get thumbnail 
		$past_thumb = get_post_thumbnail_id( $return_id ); 
	?>
		
    <form action="" id="primary_form" method="post" enctype="multipart/form-data">
	    <input id="my_image_upload" name="my_image_upload" type="file" multiple="false" multiple accept="image/*"/>
		
		<input type="hidden" name="page" value="thumbnail"/>	
		<input type="hidden" id="return_id" name="return_id" value="<?php echo $return_id; ?>"/>
		<?php wp_nonce_field( 'my_image_upload', 'my_image_upload_nonce' ); ?>
		<input type="submit" name="submit" class="button-primary" value="<?php _e( 'Submit', 'tie' ) ?>"/>
	</form>	
	</div>
	</div>
	</div>	</div>
	
<div id="block">
	
<div id="adnan-menu">
    	<h1>Select thumbnail</h1>

	
    <?php if( have_posts() ):
        echo '<div id="thumbanail-list"><ul>';
	while( have_posts() ): the_post();
	    $image_url = wp_get_attachment_url( $wp_query->ID );
		$image_id = get_image_id($image_url);
		$name = basename(get_attached_file($image_id));
		global $wpdb;
		$options1 = get_option('ln_options1'); 
		$url5 = $options1["plink_dash"]; 		?>
		 
    	<li><div class="thumb_div">
	     	<a href="<?php echo $url5.'?page=edit_post&post_id='.$return_id.'&thumb_id='.$image_id; ?>">
	    		<?php echo wp_get_attachment_image( $image_id, 'figcaption' ); ?>
			</a>
		</div></li>
			
	<?php endwhile; echo '</ul></div>';
	  	if ($wp_query->max_num_pages > 1){ echo '<div class="pagination">'; echo '<div class="wp-pagenav">'; if(function_exists('pagenavi')) { pagenavi(); } echo '</div>'; echo "</div>";  } ?>
	<?php else: ?>
	    <p><?php _e("You doesn't have any thumbnail."); ?></p>
	<?php endif; wp_reset_query(); ?>
		
    </div>
		</div>	
<?php }elseif ($_GET['page'] == "bb_code"){ get_header(); ?>
    
<div id="media_bujj">
<?php global $wpdb;
	$options1 = get_option('ln_options1'); 
	$url5 = $options1["plink_dash"]; 
	$new_post = $url5.'?page=new_post';
	$media = $url5.'?page=media';
	$bbcode = $url5.'?page=bb_code';
?>
	
<div id="block">
<div id="adnan-menu"><h1><a href="<?php echo $new_post; ?>">Add Post</a> | BB Codes</h1>	
<div class="post-contents">
  <div id="m_sec_bb">   
<div id="bb_codes">
    <h1 class="headg">For Bold text</h1> 
	<input value="[b]Your code[b]" readonly="readonly" type="text">
	<table width="100%" class="showe">
     	<tr>
	     	<td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[b]Your code[b]</td>
		</tr>
		
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
	    	<td valign="top" width="auto"><b>Your code</b></td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">For Line break</h1> 
	<input value="[br]" readonly="readonly" type="text">
	<table width="100%" class="showe">
	    <tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">Your[br]code</td>
		</tr>
		
		<tr>
    	    <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto">Your<br/>code</td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">For Italic Text</h1> 
	<input value="[i]Your Text[/i]" readonly="readonly" type="text">
	<table width="100%" class="showe">
     	<tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[i]Your Text[/i]</td>
		</tr>
		
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><i>Your Text</i></td>
		</tr>
	</table>
</div>


<div id="bb_codes">
    <h1 class="headg">Heading Text h1</h1> 
	<input value="[h1]Your Text[/h1]" readonly="readonly" type="text">
	<table width="100%" class="showe">
    	<tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[h1]Your Text[/h1]</td>
		</tr>
		
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><h1>Your Text</h1></td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">Heading Text h2</h1> 
	<input value="[h2]Your Text[/h2]" readonly="readonly" type="text">
	<table width="100%" class="showe">
       	<tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[h2]Your Text[/h2]</td>
		</tr>
		
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><h2>Your Text</h2></td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">Heading Text h3</h1> 
	<input value="[h3]Your Text[/h3]" readonly="readonly" type="text">
	<table width="100%" class="showe">
    	<tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[h3]Your Text[/h3]</td>
		</tr>
		
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><h3>Your Text</h3></td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">Heading Text h4</h1> 
	<input value="[h4]Your Text[/h4]" readonly="readonly" type="text">
   	<table width="100%" class="showe">
    	<tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[h4]Your Text[/h4]</td>
		</tr>
		
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><h4>Your Text</h4></td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">Heading Text h5</h1> 
	<input value="[h5]Your Text[/h5]" readonly="readonly" type="text">
	<table width="100%" class="showe">
    	<tr>
	    	<td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[h5]Your Text[/h5]</td>
		</tr>
		
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><h5>Your Text</h5></td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">Heading Text h6</h1> 
	<input value="[h6]Your Text[/h6]" readonly="readonly" type="text">
	<table width="100%" class="showe">
    	<tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[h6]Your Text[/h6]</td>
		</tr>
		
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><h6>Your Text</h6></td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">Start Text</h1> 
	<input value="[start]" readonly="readonly" type="text">
	<table width="100%" class="showe">
    	<tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[start]</td>
		</tr>
		<?php global $current_user; get_currentuserinfo(); ?>
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><p>প্রিয় <?php echo $current_user->display_name; ?>  ভাই প্রথমে আমার সালাম নেবেন । আশা করি ভালো আছেন । কারণ <a href="<?php echo home_url(); ?>"><?php echo get_bloginfo('name'); ?></a> এর সাথে থাকলে সবাই ভালো থাকে । আর আপনাদের দোয়ায় আমি ও ভালো আছি । তাই আজ নিয়ে এলাম আপনাদের জন্য আরেক টা নতুন টিপস । আর কথা বাড়াবো না কাজের কথায় আসি ।</p></td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">End Text</h1> 
	<input value="[end]" readonly="readonly" type="text">
	<table width="100%" class="showe">
    	<tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[end]</td>
		</tr>
		<?php global $current_user; get_currentuserinfo(); ?>
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><p>তাহলে   <?php echo $current_user->display_name; ?>   ভাই ভালো থাকুন সুস্থ থাকুন  <a href="<?php echo home_url(); ?>"><?php echo get_bloginfo('name'); ?></a> এর সাথে থাকুন । আর এই সাইট যদি ভালো লাগে আপনার বন্ধুদের জানাবেন । ধন্যবাদ ।</p></td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">Color Text</h1> 
	<input value="[color=colour]Your Text[/color]" readonly="readonly" type="text">
	<table width="100%" class="showe">
    	<tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[color=red]Your Text[/color]</td>
		</tr>
		
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><span style='color: red '>Your Text</span></td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">Rainbow color Text</h1> 
	<input value="[rainbow]Your Text[/rainbow]" readonly="readonly" type="text">
	<table width="100%" class="showe">
    	<tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[rainbow]MySQL এ কাজ শুরুর আগে একটা ডেটাবেস তৈরী করে নিতে হবে।[/rainbow]</td>
		</tr>
		
		<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><?php echo rainbow('MySQL এ কাজ শুরুর আগে একটা ডেটাবেস তৈরী করে নিতে হবে।'); ?></td>
		</tr>
	</table>
</div>

<div id="bb_codes">
    <h1 class="headg">Background-color Text</h1> 
	<input value="[bg=colour]Your Text[/bg]" readonly="readonly" type="text">
	<table width="100%" class="showe">
    	<tr>
	        <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[bg=silver]Your Text[/bg]</td>
    	</tr>
		
     	<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><span style='padding:0px 4px;background-color:silver; '>Your Text</span></td>
		</tr>
	</table>
</div>


<div id="bb_codes">
    <h1 class="headg">For codes</h1> 
	<input value="[code]Your code[code]" readonly="readonly" type="text">
	<table width="100%" class="showe"><tr>
	    <td valign="top" width="55px"><span>Used: </span></td>
		<td valign="top" width="auto">[code]&lt;div id="bb_codes"&gt;
    &lt;h1&gt;Heading Text h2&lt;/h1&gt; 
	&lt;input value="hello" readonly="readonly" type="text"&gt;
	&lt;div class="showe"&gt;&lt;span&gt;Used: &lt;/span&gt;[h2]Your Text[/h2]&lt;/div&gt;
	&lt;div class="showe"&gt;&lt;span&gt;Result: &lt;/span&gt;&lt;h2&gt;Your Text&lt;/h2&gt;&lt;/div&gt;
&lt;/div&gt;[/code]</td>
     	</tr>
	
    	<tr>
       	    <td valign="top" width="55px"><span>Result: </span></td>
	    	<td valign="top" width="auto"><textarea rows="4" id="content" class="pre_codes" style="width:100%;height: 100px;background:#fff;">&lt;div id="bb_codes"&gt;
    &lt;h1&gt;Heading Text h2&lt;/h1&gt; 
	&lt;input value="hello" readonly="readonly" type="text"&gt;
	&lt;div class="showe"&gt;&lt;span&gt;Used: &lt;/span&gt;[h2]Your Text[/h2]&lt;/div&gt;
	&lt;div class="showe"&gt;&lt;span&gt;Result: &lt;/span&gt;&lt;h2&gt;Your Text&lt;/h2&gt;&lt;/div&gt;
&lt;/div&gt;</textarea></td>
	</tr></table>
</div>


<div id="bb_codes">
    <h1 class="headg">For link / url</h1> 
	<input value="[url=your_link]link anchor[/url]" readonly="readonly" type="text">
	<table width="100%" class="showe">
     	<tr>
       	    <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[url=http://facebook.com/helim.rana12] Helim Hasan Akash[/url]</td>
		</tr>
    	<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><a href="http://facebook.com/helim.rana12">Helim Hasan Akash</a></td>
		</tr>
	</table>
</div>


<div id="bb_codes">
    <h1 class="headg">For embeed Youtube Video</h1> 
	<input value="[youtube=your_youtube_video_link]" readonly="readonly" type="text">
	<table width="100%" class="showe">
     	<tr>
       	    <td valign="top" width="55px"><span>Used: </span></td>
			<td valign="top" width="auto">[youtube=https://www.youtube.com/watch?v=jNQXAC9IVRw]</td>
		</tr>
    	<tr>
	        <td valign="top" width="55px"><span>Result: </span></td>
			<td valign="top" width="auto"><iframe src="https://www.youtube.com/embed/jNQXAC9IVRw" height="300px" width="100%"></iframe></td>
		</tr>
	</table>
</div>    
    
    
</div>


</div></div></div>
	
<?php }elseif($_GET['page'] == "media"){ 

    //Start for New Upload
if( isset($_POST['my_image_upload_nonce']) && wp_verify_nonce($_POST['my_image_upload_nonce'], 'upload_attachment') ){
		
	if ($_FILES){

        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );


        $files = $_FILES['upload_attachment'];
        $count = 0;
        $galleryImages = array();
		$media_rirle = $_POST['posttitle'];

        foreach ($files['name'] as $count => $value){

            if ($files['name'][$count]) {

                $file = array(
                    'name'     => $files['name'][$count],
                    'type'     => $files['type'][$count],
                    'tmp_name' => $files['tmp_name'][$count],
                    'error'    => $files['error'][$count],
                    'size'     => $files['size'][$count]
                );

                $upload_overrides = array( 'test_form' => false );
                $upload = wp_handle_upload($file, $upload_overrides);


                // $filename should be the path to a file in the upload directory.
                $filename = $upload['file'];

                // The ID of the post this attachment is for.
                $parent_post_id = $post_id;

                // Check the type of tile. We'll use this as the 'post_mime_type'.
                $filetype = wp_check_filetype( basename( $filename ), null );

                // Get the path to the upload directory.
                $wp_upload_dir = wp_upload_dir();
				
				$cat = array();
				$eror = "";
				$user_id 		= $current_user->user_id;
				$md_title 	= $_POST['md_title'];
				
				if( $md_title == "" ){
	             	$eror .= __('Please fill in Post Title field') . "<br />";
				}
				
				if ( $eror == "" ){

                // Prepare an array of post data for the attachment.
                $attachment = array(
                    'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ), 
                    'post_mime_type' => $filetype['type'],
                    'post_title'     => $md_title,
                    'post_content'   => '',
                    'post_status'    => 'inherit'
                );

                // Insert the attachment.
                $attach_id = wp_insert_attachment( $attachment, $filename, $parent_post_id );

                // Make sure that this file is included, as wp_generate_attachment_metadata() depends on it.
                require_once( ABSPATH . 'wp-admin/includes/image.php' );

                // Generate the metadata for the attachment, and update the database record.
                $attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
                wp_update_attachment_metadata( $attach_id, $attach_data );
				
				global $wpdb;
				$options1 = get_option('ln_options1'); 
				$url5 = $options1["plink_dash"]; 
				
				$redirect_edit = $url5.'?page=media';
				header('Location:'.$redirect_edit);
				}
			}
	    }
	}
}  get_header(); ?>

<?php global $wpdb;
	$options1 = get_option('ln_options1'); 
	$url5 = $options1["plink_dash"]; 
	$media = $url5.'?page=media';
	$new_posts = $url5.'?page=new_post';
?>
	
<div id="block">
<div id="post-menu"><h1><a href="<?php echo $new_posts; ?>">Posts</a> | Add Screenshot </h1>
<div class="">
    <?php if ($eror != "") {
	    echo "<div id='eror'><p>".$eror."</p></div>";
	} ?> 
		
	<form action="" id="post_form" method="post" enctype="multipart/form-data" >
        <p class="liner">
	        <label for="md_title"><?php _e('Image Title'); ?></label><br/>
	    	<input style="width: 80%;" id="md_title" name="md_title" title="Search" value="<?php echo bloginfo('name'); ?>" onfocus="if (this.value == '<?php echo bloginfo('name'); ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php echo bloginfo('name'); ?>';}" type="text">
       </p>
		
		<p class="liner">
	        <label for="gfgfg"><?php _e('Select Image'); ?></label><br/>
			<input type="file" name="upload_attachment[]" class="files" multiple="multiple" multiple accept="image/*" id="gfgfg"/>
		</p>	
		
		<?php wp_nonce_field( 'upload_attachment', 'my_image_upload_nonce' ); ?>
		<input id="submit" type="submit" value="Upload" />						
	</form>	
</div>
</div>	
</div>
<div id="block">
<div id="post-menu"><h1>Media Library</h1>

<div class="page-content">
    <form action="<?php echo $url5.'?page=media';  ?>" id="search_form" method="get">
	    <input type="hidden" name="page" value="media" />
		<table id="p_fonm" cellpadding="0" cellspacing="0" width="100%"><tbody><tr>
     	    <td width="auto">
                <input style="width: 95%;" id="at-search" name="search" title="Search" value="<?php _e('Search Images'); ?>" onfocus="if (this.value == '<?php _e('Search Images'); ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php _e('Search Images'); ?>';}" type="text">
            </td>
	     	<td width="55px">
                <input class="at-submit" value="<?php _e('Search'); ?>" type="Submit" style="margin-left: 5px; float: right;">
          	</td>
		</tr></tbody></table>			
	</form>
</div></div></div>
	<div id="block">
<div id="post_bujj">
	<?php // Search Result Count
    $search = isset( $_REQUEST['search'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['search'] )
	: $_REQUEST['search'] ) : '';
	$search     = urldecode( $search ); 
	$curnt_user = get_current_user_id();
	
    $item = array(
    		'post_type' => 'attachment',
			'post_status' => array('publish', 'draft', 'inherit'),
			's' => $search,
			'showposts' => -1,
			'posts_per_page' => 16,
			'orderby' => 'menu_order ID',
			'order' => 'DESC',
			'post_mime_type' => 'image',
			'author' => $curnt_user,
		    'paged' => get_query_var('paged')
	); 
	$s_query = new WP_Query($item);
	$num = $s_query->post_count;	
	
	// Query Strart
	$args = array(
    		'post_type' => 'attachment',
			'post_status' => array('publish', 'draft', 'inherit'),
			's' => $search,
			'numberposts' => -1,
			'posts_per_page' => 16,
			'orderby' => 'menu_order ID',
			'order' => 'DESC',
			'post_mime_type' => 'image',
			'author' => $curnt_user,
		    'paged' => get_query_var('paged')
	); 
	$wp_query = new WP_Query($args); ?>
	
	<?php if($search){ ?>
        <div class="breadcumbs">
          	<script> jQuery('#at-search').val('<?php echo $search; ?>')</script>
    		<p> <?php _e('Search Result for') ?><span> “<?php echo $search; ?>” </span><?php _e('&mdash;') ?> <?php echo $num; ?> <?php if( $num > 1 ){ _e( 'files' ); }else{ _e( 'file' ); } ?></p>
	    	<a href="<?php echo $url5.'?page=media';  ?>" id="cancel"></a>
     	</div>
	<?php } 
	
	if( have_posts() ): echo '<div id="at_content"><ul>'; while( have_posts() ): the_post(); 
     	$image_url = wp_get_attachment_url();
     	$image_id = get_image_id($image_url);
		
		$basename = basename(get_attached_file($image_id)); 
		$pathname = pathinfo($basename);
		
		$filename = remove_unnecessary_slug(get_the_title($image_id ));
		
		$type = get_post_mime_type($image_id);
		
		$docsize = @filesize( get_attached_file( $image_id ) );
		if (FALSE === $docsize){$docsize = 0;}else{$docsize = size_format($docsize, 2);}
		
		$permanent_wpnonce = esc_html( '_wpnonce=' . wp_create_nonce( "delete-post_$image_id" ) );
		$perman_url = home_url( '/' )."wp-admin/post.php?post=$image_id";
		$delete_url = esc_url( $perman_url . "&action=delete&$permanent_wpnonce" );
		
		if(wp_attachment_is_image( $image_id)){$metadata = wp_get_attachment_metadata($image_id);
		$width = $metadata['width'];
		$height = $metadata['height'];}
		
		$file_date = get_the_date('M j, Y'); ?>
      
     	<li class="at_list">
	     	<div id="img_id">
		        <div class="img"><center><a href="<?php echo wp_get_attachment_url( $image_id ); ?>" title="<?php echo $name; ?>" target="_blank"><?php echo wp_get_attachment_image( $image_id, 'figcaption' ); ?></a></center></div>
				<div class="id_Code"><input value="[img=<?php echo $image_id; ?>]" type="text" readonly="readonly" /></div>
			</div>
	    </li>
		
	<?php endwhile; echo'</ul></div></div></div><div class="pagination">';
	if ($wp_query->max_num_pages > 1){ 
	    echo '<div class="wp-pagenav">'; if(function_exists('pagenavi')) { pagenavi(); } echo '</div>';
	} ?><?php else: ?>
     	<div id="at_content">
           <p><?php _e('No Result match in you query.','tie'); ?></p>
		</div>
	<?php endif; wp_reset_query(); ?>
</div></div>

<?php }elseif ($_GET['action'] == "confirm_thumb"){ 
    
	//Set Post Thumbnail
	if ( $_REQUEST['page'] == 'thumbnail' && isset( $_POST['submit'] ) ){
        $return_id  = $_POST['return_id'];
		$thumb_id = isset( $_REQUEST['thumb_id'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['thumb_id'] )
	    : $_REQUEST['thumb_id'] ) : '';
	    $thumb_id = urldecode( $thumb_id );
		
		if( ! $return_id || ! $thumb_id ){
			$err .= "<strong>ERROR</strong>: An Error was occurrence.";
		}
		
		if ( $err == "" ){
	     	if( (current_user_can('editor') || current_user_can('administrator') || current_user_can('author')) ){
				$post_sts = 'publish';
			}else{
				$post_sts = 'pending';
			}
			
			$my_post = array(
               	'ID' => $return_id,
	     		'post_status'	=> $post_sts,
			);
			
			// Upgrade post to publish
	    	wp_update_post($my_post);
			
			// Set Post Thumbnail
			update_post_meta($return_id,'_thumbnail_id',$thumb_id);
			
			//Post save as draft and redirect url
			global $wpdb;
			$options1 = get_option('ln_options1'); 
			$url5 = $options1["plink_dash"]; 
			$redirected_ul = $url5;
			header('Location:'.$redirected_ul);
		}
    } 
	
	global $wpdb;
	$options1 = get_option('ln_options1'); 
	$url5 = $options1["plink_dash"]; 
	get_header(); ?>
	
    <div id="block">
	
	<div id="adnan-menu">
    	<h1>Confirm thumbnail</h1>
	
	
	<div class="breadcumbs">Confirm to make this thumbnail?</div>
	<div class="page-content">
	<?php if ( $err != "" ){
		echo "<div id='error_rep'>".$err."</div>";
	}elseif ( $_REQUEST['success'] ){ ?>
     	<div id='error_suc'><?php _e('The Post has been Published. '); ?><a href="<?php echo $post_short; ?>"><?php _e('View Post'); ?></a></div>
	<?php } ?>
	
	<?php // get post link from post
	    $return_id = isset( $_REQUEST['return_id'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['return_id'] )
	    : $_REQUEST['return_id'] ) : '';
	    $return_id = urldecode( $return_id );
		// get post link from post
	    $thumb_id = isset( $_REQUEST['thumb_id'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['thumb_id'] )
	    : $_REQUEST['thumb_id'] ) : '';
	    $thumb_id = urldecode( $thumb_id );
	 ?>
		
    	<form action="" id="cnf_form" method="post" enctype="multipart/form-data">
	    	<input type="hidden" name="page" value="thumbnail"/>	
			<input type="hidden" id="return_id" name="return_id" value="<?php echo $return_id; ?>"/>
			<input type="hidden" id="thumb_id" name="thumb_id" value="<?php echo $thumb_id; ?>"/>
			
			<input type="submit" name="submit" class="button-primary" value="<?php _e( 'Confirm', 'tie' ) ?>"/>
			<a href="<?php echo $url5.'?page=thumbnail&return_id='.$return_id; ?>" id="back"><?php _e('Back'); ?></a>
		</form>
		
		<div id="cfm_yhum"><?php echo wp_get_attachment_image( $thumb_id, 'figcaption' ); ?></div>
    </div></div></div>
<?php }elseif( $_GET['page'] == 'edit_post' ){ 
    
	//Edit the post
    $query = new WP_Query(
     	array(
	    	'post_type' => 'post', 
			'posts_per_page' =>'-1', 
			'post_status' => array('publish', 'pending', 'draft', 'private', 'trash') 
		) );
		
	if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post();
    	if(isset($_GET['post_id']) && $_GET['post_id'] == $post->ID) {
	    	$content_id = $post->ID;
	    	$title      = get_the_title();
			$content    = get_the_content();
			$tags       = strip_tags( get_the_term_list( $content_id, 'post_tag', '', ', ', '' ) ); 
			$cate       = get_the_category($content_id); 
			$category   = $cate[0]->cat_ID;
		}
	endwhile; endif;
	wp_reset_query();
	
	if( isset($_POST['update-post']) && isset($_POST['post_nonce_field']) && wp_verify_nonce($_POST['post_nonce_field'], 'post_nonce') ){
		$post_id = isset( $_REQUEST['post_id'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['post_id'] )
		: $_REQUEST['post_id'] ) : '';
		// get thumbnail id
		$thumb_id = isset( $_REQUEST['thumb_id'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['thumb_id'] )
		: $_REQUEST['thumb_id'] ) : '';
		$thumb_id = urldecode( $thumb_id );
		// get thumbnail
		$image_id     = get_post_thumbnail_id($post_id);
		
		$check_id     = post_exist_check($post_id);   
		$pe_cat       = array();
		$err          = "";
		$user_id      = $current_user->user_id;
		$pe_title 	  = $_POST['posttitle'];
		$pe_content   = $_POST['postcontent'];
		$pe_cat[0]	  = $_POST['cat'];	
		$pe_tags 	  = $_POST['post_tags'];
		$current_page = $_POST['_wp_http_referer'];
		
		if ( $post_id !== $check_id ){
       		$error .= __("<p>The post doesn't exist.</p>");
		}
		if ( $pe_title == "" && $check_id ){
			$error .= __('<p>Please fill in Title field.</p>');
		}
		if ( $pe_content == "" && $check_id ){
			$error .= __('<p>Please fill in Post Content field.</p>');
		}
		if($check_id){
			if ( $pe_cat[0] == "-1" ){
				$error .= __('<p>Please choose the post Category.</p>');
			}else{
				global $wpdb;
				$pe_cat_ids = (array) $wpdb->get_col("SELECT term_id FROM $wpdb->terms");
				if ( !in_array($pe_cat[0], $pe_cat_ids) && $pe_cat != "-1") {
					$error .= __("<p>This category doesn't exist</p>");
				}
			}
		}
		
		if ( $error == "" && $check_id ){
      		if( ((current_user_can('editor') || current_user_can('administrator') || current_user_can('author')) && $thumb_id ) || ((current_user_can('editor') || current_user_can('administrator') || current_user_can('author')) && has_post_thumbnail( $post_id )) ){
				$post_sts = 'publish';
			}elseif( (current_user_can('editor') || current_user_can('administrator') || current_user_can('author')) && ! has_post_thumbnail( $check_id ) ){
				$post_sts = 'draft';
			}else{
				$post_sts = 'pending';
			}
			
			$post_information = array(
     	     	'ID'            => $post_id,
				'post_title'    => $pe_title,
				'post_content'  => $pe_content,
				'post_category'	=> $pe_cat,
				'tags_input'    => $pe_tags,
				'post_type'     => 'post',
				'post_status'   => $post_sts,
			);
			
	    	wp_update_post($post_information);
			
			if( $thumb_id ){
				$confirm_thum = $thumb_id;
			}elseif( has_post_thumbnail( $post_id ) && !$thumb_id ){
				$confirm_thum = $image_id;
			}
			
			// Set Post Thumbnail
			update_post_meta($post_id,'_thumbnail_id',$confirm_thum);
			
			global $wpdb;
			$options1 = get_option('ln_options1'); 
			$url5 = $options1["plink_dash"]; 
			
			$redirect_edit = $url5;
			header('Location:'.$redirect_edit);
		}	
	}elseif( isset($_POST['edit-draft']) && isset($_POST['post_nonce_field']) && wp_verify_nonce($_POST['post_nonce_field'], 'post_nonce') ){
		$post_id = isset( $_REQUEST['post_id'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['post_id'] )
		: $_REQUEST['post_id'] ) : '';
		// get thumbnail id
		$thumb_id = isset( $_REQUEST['thumb_id'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['thumb_id'] )
		: $_REQUEST['thumb_id'] ) : '';
		$thumb_id = urldecode( $thumb_id );
		// get thumbnail
		$image_id     = get_post_thumbnail_id($post_id);
		
		
		$check_id     = post_exist_check($post_id);   
		$pe_cat       = array();
		$err          = "";
		$user_id      = $current_user->user_id;
		$pe_title 	  = $_POST['posttitle'];
		$pe_content   = $_POST['postcontent'];
		$pe_cat[0]	  = $_POST['cat'];	
		$pe_tags 	  = $_POST['post_tags'];
		$current_page = $_POST['_wp_http_referer'];
		
		if ( $post_id !== $check_id ){
       		$error .= __("<p>The post doesn't exist.</p>");
		}
		
		if ( $error == "" && $check_id ){
      		$post_information = array(
     	     	'ID'            => $post_id,
				'post_title'    => $pe_title,
				'post_content'  => $pe_content,
				'post_category'	=> $pe_cat,
				'tags_input'    => $pe_tags,
				'post_type'     => 'post',
				'post_status'   => 'draft',
			);
			
	    	wp_update_post($post_information);
			
			if( $thumb_id ){
				$confirm_thum = $thumb_id;
			}elseif( has_post_thumbnail( $post_id ) && !$thumb_id ){
				$confirm_thum = $image_id;
			}
			
			// Set Post Thumbnail
			update_post_meta($post_id,'_thumbnail_id',$confirm_thum);
			
			global $wpdb;
			$options1 = get_option('ln_options1'); 
			$url5 = $options1["plink_dash"]; 
			
			$redirect_edit = $url5;
			header('Location:'.$redirect_edit);
		}	
	} get_header(); ?>
	
<div id="block">
    	<?php global $wpdb; $options1 = get_option('ln_options1'); $url5 = $options1["plink_dash"]; ?>
		
	   <div id="adnan-menu">
           	<h1><a href="<?php echo $url5; ?>">All Post</a> | <a href="<?php echo $url5.'?page=new_post'; ?>">Add New Post</a> | Editor</h1>
		
		
		<?php 
	   	$post_id = isset( $_REQUEST['post_id'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['post_id'] )
		: $_REQUEST['post_id'] ) : '';
		$post_id = urldecode( $post_id );
		// get thumbnail id
		$thumb_id = isset( $_REQUEST['thumb_id'] ) ? ( get_magic_quotes_gpc( ) ? stripcslashes( $_REQUEST['thumb_id'] )
		: $_REQUEST['thumb_id'] ) : '';
		$thumb_id = urldecode( $thumb_id );
		// get thumbnail
		$image_id     = get_post_thumbnail_id($post_id);
		// Short Url for visit Post
		$edit_short	= esc_url(wp_get_shortlink( $post_id ));
		
		if ($error != "") {
	    	echo "<div id='error_edit'>".$error."</div>";
		}elseif ( $_REQUEST['return'] ){ ?>
         	<div id='success_edit'><?php _e('Post has been Updated. '); ?><a href="<?php echo $edit_short; ?>"><?php _e('View Post'); ?></a></div>
		<?php } ?>
		
		<?php if( $thumb_id ){ ?>
	    	<div class="breadcumbs">
		    	<div id="img_sec"><?php echo wp_get_attachment_image( $thumb_id, 'figcaption' ); ?></div>
				<div id="thum"><a href="<?php echo $url5.'?page=edit_thumb&return_id='.$post_id; ?>" id="op_Thi"><?php _e('Change thumbnail'); ?></a></div>
			</div>
		<?php }elseif( has_post_thumbnail( $post_id ) && !$thumb_id ){ ?>
	    	<div class="breadcumbs">
		    	<div id="img_sec"><?php echo wp_get_attachment_image( $image_id, 'figcaption' ); ?></div>
				<div id="thum"><a href="<?php echo $url5.'?page=edit_thumb&return_id='.$post_id; ?>" id="op_Thi"><?php _e('Change thumbnail'); ?></a></div>
			</div>
		<?php }elseif( !has_post_thumbnail( $post_id ) && !$thumb_id ){ ?>
			<div id="thum">
		        <a href="<?php echo $url5.'?page=edit_thumb&return_id='.$post_id; ?>" id="op_Thi">Add Thumbnail</a>	
		    </div>
		<?php } ?>
		<form action="" id="primary_edit" method="post" enctype="multipart/form-data">
         	<p class="liner">
	            <label for="posttitle"><?php _e('Post Title'); ?></label><br/>
	          	<input id="posttitle" name="posttitle" value="<?php echo $title; ?>" type="text">
			</p>
			
		 	<p class="liner">
	            <label for="postcontent"><?php _e('Post Content'); ?></label><br/>
	            <textarea name="postcontent" id="postcontent" cols="7" rows="6"><?php echo $content; ?></textarea>
			</p>
			
			<p class="liner">
	           	<label for="cat"><?php _e('Category'); ?></label><br/>
	     		<?php wp_dropdown_categories('show_option_none=Select Category — &selected='.$category.'&orderby=name&order=ASC&hide_empty=0&hierarchical=1'); ?>
			</p>
			
	 		<p class="liner">
	        	<label for="post_tags"><?php _e('Post Tags - '); ?><span> <?php _e('comma(,) separate'); ?></span></label>
	          	<input id="post_tags" name="post_tags" value="<?php echo $tags; ?>" type="text">
			</p>
			
			<?php wp_nonce_field('post_nonce', 'post_nonce_field'); ?>
			<input id="update-post" name="update-post" type="submit" value="Update post" />
			<a href="<?php echo $edit_short; ?>" id="prev">Preview</a>
			<input id="edit-draft" name="edit-draft" type="submit" value="Save as draft" />	
		</form>
	</div></div>
	
<?php }elseif($_GET['page'] == "new_post"){ 

    //Submit Post as Drafts
	if (isset($_POST['submit-post']) && isset($_POST['action']) && $_POST['action'] == 'post' && wp_verify_nonce($_POST['_wpnonce'],'sub_post')){
		
		$cat = array();
		$err = "";
		$user_id 		= $current_user->user_id;
		$post_title 	= $_POST['post_title'];
		$post_content 	= $_POST['post_content'];
		$cat[0]	 		= $_POST['cat'];	
		$post_tags 		= $_POST['post_tags'];
		$current_page   = $_POST['_wp_http_referer'];
		
		if ( $post_title == "" ){
	     	$err .= __('Please fill in Post Title field') . "<br />";
		}
		if ( $post_content == "" ){
	     	$err .= __('Please fill in Post Content field') . "<br />";
		}
		if ( $cat[0] == "-1" ){
			$err .= __('Please choose your Post Category') . "<br />";
		}else{
			global $wpdb;
			$cat_ids = (array) $wpdb->get_col("SELECT term_id FROM $wpdb->terms");
			if ( !in_array($cat[0], $cat_ids) && $cat != "-1") {
				$err .= __('This category doesn\'t exist') . "<br />";
			}
		}	
		
		if ( $err == "" ){
	    	if( (current_user_can('editor') || current_user_can('administrator') || current_user_can('author')) && has_post_thumbnail( $return_id ) ){
				$post_sts = 'publish';
			}elseif( (current_user_can('editor') || current_user_can('administrator') || current_user_can('author')) && ! has_post_thumbnail( $return_id ) ){
				$post_sts = 'draft';
			}else{
				$post_sts = 'pending';
			}
			
			$post_information = array(
	    		'post_title'	=> $post_title,
				'post_content'	=> $post_content,
				'post_category'	=> $cat,
				'tags_input'	=> $post_tags,
				'post_type'     => 'post',
				'post_status'	=> $post_sts
			);
			
			$post_id = wp_insert_post($post_information);
			
			//Post save as draft and redirect link
			global $wpdb;
			$options1 = get_option('ln_options1'); 
			$url5 = $options1["plink_dash"]; 
			$redirect_link = $url5.'?page=thumbnail&return_id='.$post_id;
			wp_redirect( $redirect_link );
		}
	}elseif (isset($_POST['draft-post']) && isset($_POST['action']) && $_POST['action'] == 'post' && wp_verify_nonce($_POST['_wpnonce'],'sub_post')){
		
		$cat = array();
		$err = "";
		$user_id 		= $current_user->user_id;
		$post_title 	= $_POST['post_title'];
		$post_content 	= $_POST['post_content'];
		$cat[0]	 		= $_POST['cat'];	
		$post_tags 		= $_POST['post_tags'];
		$current_page   = $_POST['_wp_http_referer'];
		
		if ( $err == "" ){
	    	$post_information = array(
	    		'post_title'	=> $post_title,
				'post_content'	=> $post_content,
				'post_category'	=> $cat,
				'tags_input'	=> $post_tags,
				'post_type'     => 'post',
				'post_status'	=> 'draft'
			);
			
			$post_id = wp_insert_post($post_information);
			
			//Post save as draft and redirect link
			global $wpdb;
			$options1 = get_option('ln_options1'); 
			$url5 = $options1["plink_dash"]; 
			$redirect_link = $url5.'?page=edit_post&post_id='.$post_id.'&status=drsft';
			wp_redirect( $redirect_link );
		}
	} get_header(); ?>
	
	<?php global $wpdb;
		$options1 = get_option('ln_options1'); 
		$url5 = $options1["plink_dash"]; 
		$media = $url5.'?page=media';
		$bbcode = $url5.'?page=bb_code';
	?>
	
<div id="block">
	
	<div id="post-menu">
    	<h1><a href="<?php echo $url5; ?>">Posts</a> | Add Post | <a href="<?php echo $media; ?>">Add Screenshot</a> | <a href="<?php echo $bbcode; ?>">Add BB Codes</a></h1>

	
	
	
	<div class="liner"><b>Basic Rules: (Updated at 05.02.18) </b>
		<ul>
			<li>বাংলায় পোষ্ট করলে শুদ্ধ বাংলা ব্যবহার করুন। </li> 
			<li>পোষ্ট এর সাথে সম্পুর্কযুক্ত ক্যাটাগরী/ফিচারড ইমেজ/ট্যাগ ব্যবহার করুন। </li>
			
			<br><b>বাধ্যতামূলক কিছু নিয়মঃ</b><br>
			<li>
			**সম্পূর্ন নিজের ভাষায় পোষ্ট লিখুন...কপিপেষ্ট পরিহার করুন। <br>
			** কেউ কপিপেষ্ট করেছে এমন প্রমান পেলে সাথে সাথে ট্রেইনার থেকে তাকে বাতিল করা হবে
			
			</li>
		</ul>
	</div>
	
	<?php if ($err != "") {
	    echo "<div id='eror'><p>".$err."</p></div>";
	} ?> 
		
		<form action="" id="post_form" method="post" enctype="multipart/form-data">
        	<p class="liner">
	        	<label for="post_title"><?php _e('Enter title here'); ?></label><br/>
	    		<input type="text" id="post_title" name="post_title" placeholder="Enter title here" value="<?php echo $post_title;?>" size="60" tabindex="1"/>
	    	</p>
			
			<p class="liner">
	        	<label for="post_content"><?php _e('Content'); ?></label><br/>
	           	<textarea name="post_content" id="post_content" cols="7" rows="5" tabindex="2"><?php echo $post_content; ?></textarea>
	    	</p>
			
		
	<p class="liner">
		<label for="cat">Post Category</label><br/>
		<?php if ( current_user_can('administrator')) { 
		    wp_dropdown_categories('show_option_none=Choose Post Category&orderby=name&order=ASC&hide_empty=0&hierarchical=1'); 
		}else{
			wp_dropdown_categories('show_option_none=Choose Post Category&orderby=name&order=ASC&hide_empty=0&hierarchical=1&exclude=200'); 
		}?>
	</p>			
			<p class="liner">
	         	<label for="post_tags"><?php _e('Tags'); ?><small> <?php _e('(comma(,) separate.)'); ?></small></label>
           		<input type="text" id="post_tags" name="post_tags" value="<?php echo $post_tags;?>" size="60" tabindex="3"/>
			</p>		
			
			<input type="hidden" name="action" value="post" />
			<?php wp_nonce_field( 'sub_post' ); ?>
			
			<input id="submit-post" name="submit-post" type="submit" value="Submit post" />
			<input id="draft-post" name="draft-post" type="submit" value="Save as draft" />					
		</form>
	</div>
	
<?php }elseif($_GET['post_status'] == "publish"){ ?>

	<?php global $wpdb;
		$options1 = get_option('ln_options1'); 
		$url5 = $options1["plink_dash"]; 
		get_header();
	?>
	
	<div id="block">
	
	<div id="adnan-menu">
    	<h1>All Post | <a href="<?php echo $url5.'?page=new_post'; ?>">Add New Post</a></h1>
	
	<div class="breadcumbs"><?php
	    $user_id = get_current_user_id();
		$publish = PostCount($user_id, 'publish');
		$pending = PostCount($user_id, 'pending');
		$draft = PostCount($user_id, 'draft');
		$trash = PostCount($user_id, 'trash');
		$all = $publish + $pending + $draft + $trash;?>
		    <a href='<?php echo $url5.'?post_status=all'; ?>'><?php _e('All'); ?><?php if ($all > 0){ ?> <span class='count'>(<?php echo $all; ?>)</span><?php } ?></a> <?php _e('|'); ?> 
			<a href='<?php echo $url5.'?post_status=publish'; ?>' class="active"><?php _e('Published'); ?><?php if ($publish > 0){ ?> <span class='count'>(<?php echo $publish; ?>)</span><?php } ?></a> <?php _e('|'); ?> 
			<a href='<?php echo $url5.'?post_status=draft'; ?>'><?php _e('Draft'); ?><?php if ($draft > 0){ ?> <span class='count'>(<?php echo $draft; ?>)</span><?php } ?></a> <?php _e('|'); ?>
			<a href='<?php echo $url5.'?post_status=pending'; ?>'><?php _e('Pending'); ?><?php if ($pending > 0){ ?> <span class='count'>(<?php echo $pending; ?>)</span><?php } ?></a> <?php _e('|'); ?>
			<a href="<?php echo $url5.'?post_status=trash'; ?>"><?php _e('Trash'); ?><?php if ($trash > 0){ ?> <span class='count'>(<?php echo $trash; ?>)</span><?php } ?></a>
	</div></div>

	<div id="post-menu">
	<?php $user_id = get_current_user_id();
		$args=array(
		    'post_type' => 'post',
			'post_status' => 'publish',
			'author' => $user_id,
			'numberposts' => -1,
			'posts_per_page' => 15,
			'paged' => get_query_var('paged'));                       
		
		$wp_query = new WP_Query($args);
		if( have_posts() ): echo '<ul class="posts">'; while( have_posts() ): the_post();
		
		// Move to Trash
		$postid = get_the_ID();
		$trash_wpnonce = esc_html( '_wpnonce=' . wp_create_nonce( "trash-post_$postid" ) );
		$trash_url = home_url( '/' )."wp-admin/post.php?post=$postid";
		$trash_del = esc_url( $trash_url . "&action=trash&$trash_wpnonce" );
	?>
		<li>
         
    		    <?php if ( function_exists("has_post_thumbnail") && has_post_thumbnail() ) : ?>	
	     	        <?php the_post_thumbnail('small');  ?>
    			<?php else: ?>
    				<img src="<?php echo get_template_directory_uri(); ?>/images/default.png" />	
     			<?php endif; ?>
         
			<div class="post_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a> <?php _e('-'); echo get_post_status( get_the_ID() ); ?></div> 
			<div id="list_time"><?php the_time( 'j M, Y' ); ?></div>
			<div id="list_head">
			    <a href="<?php echo $url5.'?page=edit_post&post_id='.$postid; ?>"><?php _e('Edit'); ?></a><?php _e(' | '); ?><a href="<?php the_permalink(); ?>"><?php _e('View'); ?></a><?php _e(' | '); ?><a href="<?php echo $trash_del ?>"><?php _e('Trash'); ?></a>
			</div>
		</li><!-- .item-list -->
    <?php endwhile;?>
    </ul>
	<?php echo '<div class="pagination">'; if ($wp_query->max_num_pages > 1){echo '<div class="wp-pagenav">'; if(function_exists('pagenavi')) { pagenavi(); } echo '</div>';}  echo '</div>'; ?>
	<?php else: ?>
		<div align="center" class="no-result">
		    <p><?php _e('No posts found in Publish','tie'); ?></p>
		</div>
	<?php endif; wp_reset_query(); ?>
	</div><!-- .post_list /-->
	</div>
	
<?php }elseif($_GET['post_status'] == "draft"){ ?>
	
	<?php global $wpdb;
		$options1 = get_option('ln_options1'); 
		$url5 = $options1["plink_dash"]; 
		get_header();
	?>
	
	<div id="block">
	
	<div id="adnan-menu">
    	<h1>All Post | <a href="<?php echo $url5.'?page=new_post'; ?>">Add New Post</a></h1>

	
	<div class="breadcumbs"><?php
	    $user_id = get_current_user_id();
		$publish = PostCount($user_id, 'publish');
		$pending = PostCount($user_id, 'pending');
		$draft = PostCount($user_id, 'draft');
		$trash = PostCount($user_id, 'trash');
		$all = $publish + $pending + $draft + $trash;?>
		    <a href='<?php echo $url5.'?post_status=all'; ?>'><?php _e('All'); ?><?php if ($all > 0){ ?> <span class='count'>(<?php echo $all; ?>)</span><?php } ?></a> <?php _e('|'); ?> 
			<a href='<?php echo $url5.'?post_status=publish'; ?>'><?php _e('Published'); ?><?php if ($publish > 0){ ?> <span class='count'>(<?php echo $publish; ?>)</span><?php } ?></a> <?php _e('|'); ?> 
			<a href='<?php echo $url5.'?post_status=draft'; ?>' class="active"><?php _e('Draft'); ?><?php if ($draft > 0){ ?> <span class='count'>(<?php echo $draft; ?>)</span><?php } ?></a> <?php _e('|'); ?>
			<a href='<?php echo $url5.'?post_status=pending'; ?>'><?php _e('Pending'); ?><?php if ($pending > 0){ ?> <span class='count'>(<?php echo $pending; ?>)</span><?php } ?></a> <?php _e('|'); ?>
			<a href="<?php echo $url5.'?post_status=trash'; ?>"><?php _e('Trash'); ?><?php if ($trash > 0){ ?> <span class='count'>(<?php echo $trash; ?>)</span><?php } ?></a>
	</div>
	</div>
	<div id="post-menu">
	<?php $user_id = get_current_user_id();
		$args=array(
		    'post_type' => 'post',
			'post_status' => 'draft',
			'author' => $user_id,
			'numberposts' => -1,
			'posts_per_page' => 15,
			'paged' => get_query_var('paged'));                       
		
		$wp_query = new WP_Query($args);
		if( have_posts() ): echo '<ul class="posts">'; while( have_posts() ): the_post(); 
		
		// Move to Trash
		$postid = get_the_ID();
		$trash_wpnonce = esc_html( '_wpnonce=' . wp_create_nonce( "trash-post_$postid" ) );
		$trash_url = home_url( '/' )."wp-admin/post.php?post=$postid";
		$trash_del = esc_url( $trash_url . "&action=trash&$trash_wpnonce" );
	?>
		<li>
            
    		    <?php if ( function_exists("has_post_thumbnail") && has_post_thumbnail() ) : ?>	
	     	        <?php the_post_thumbnail('small');  ?>
    			<?php else: ?>
    				<img src="<?php echo get_template_directory_uri(); ?>/images/default.png" />	
     			<?php endif; ?>
            
			<div class="post_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a> <?php _e('-'); echo get_post_status( get_the_ID() ); ?></div> 
			<div id="list_time"><?php the_time( 'j M, Y' ); ?></div>
			<div id="list_head">
			    <a href="<?php echo $url5.'?page=edit_post&post_id='.$postid; ?>"><?php _e('Edit'); ?></a><?php _e(' | '); ?><a href="<?php the_permalink(); ?>"><?php _e('View'); ?></a><?php _e(' | '); ?><a href="<?php echo $trash_del ?>"><?php _e('Trash'); ?></a>
			</div>
		</li><!-- .item-list -->
    <?php endwhile;?>
       	</ul>
	<?php echo '<div class="pagination">'; if ($wp_query->max_num_pages > 1){echo '<div class="wp-pagenav">'; if(function_exists('pagenavi')) { pagenavi(); } echo '</div>'; }  echo '</div>'; ?>
		<?php else: ?>
	<div align="center" class="no-result">
     	<p><?php _e('No posts found in Draft','tie'); ?></p>
	</div>
	<?php endif; wp_reset_query(); ?>
	</div><!-- .post_list /-->
	</div>
		
<?php }elseif($_GET['post_status'] == "pending"){ ?>
	
	<?php global $wpdb;
		$options1 = get_option('ln_options1'); 
		$url5 = $options1["plink_dash"]; 
		get_header();
	?>
	
	<div id="block">
	
	<div id="adnan-menu">
    	<h1>All Post | <a href="<?php echo $url5.'?page=new_post'; ?>">Add New Post</a></h1>
	
	<div class="breadcumbs"><?php
	    $user_id = get_current_user_id();
		$publish = PostCount($user_id, 'publish');
		$pending = PostCount($user_id, 'pending');
		$draft = PostCount($user_id, 'draft');
		$trash = PostCount($user_id, 'trash');
		$all = $publish + $pending + $draft + $trash;?>
		    <a href='<?php echo $url5.'?post_status=all'; ?>'><?php _e('All'); ?><?php if ($all > 0){ ?> <span class='count'>(<?php echo $all; ?>)</span><?php } ?></a> <?php _e('|'); ?> 
			<a href='<?php echo $url5.'?post_status=publish'; ?>'><?php _e('Published'); ?><?php if ($publish > 0){ ?> <span class='count'>(<?php echo $publish; ?>)</span><?php } ?></a> <?php _e('|'); ?> 
			<a href='<?php echo $url5.'?post_status=draft'; ?>'><?php _e('Draft'); ?><?php if ($draft > 0){ ?> <span class='count'>(<?php echo $draft; ?>)</span><?php } ?></a> <?php _e('|'); ?>
			<a href='<?php echo $url5.'?post_status=pending'; ?>' class="active"><?php _e('Pending'); ?><?php if ($pending > 0){ ?> <span class='count'>(<?php echo $pending; ?>)</span><?php } ?></a> <?php _e('|'); ?>
			<a href="<?php echo $url5.'?post_status=trash'; ?>"><?php _e('Trash'); ?><?php if ($trash > 0){ ?> <span class='count'>(<?php echo $trash; ?>)</span><?php } ?></a>
	</div></div>

	<div id="post-menu">
	<?php $user_id = get_current_user_id();
		$args=array(
		    'post_type' => 'post',
			'post_status' => 'pending',
			'author' => $user_id,
			'numberposts' => -1,
			'posts_per_page' => 15,
			'paged' => get_query_var('paged'));                       
		
		$wp_query = new WP_Query($args);
		if( have_posts() ): echo '<ul class="posts">'; while( have_posts() ): the_post(); 
		
		// Move to Trash
		$postid = get_the_ID();
		$trash_wpnonce = esc_html( '_wpnonce=' . wp_create_nonce( "trash-post_$postid" ) );
		$trash_url = home_url( '/' )."wp-admin/post.php?post=$postid";
		$trash_del = esc_url( $trash_url . "&action=trash&$trash_wpnonce" );
	?>
		<li>
            
    		    <?php if ( function_exists("has_post_thumbnail") && has_post_thumbnail() ) : ?>	
	     	        <?php the_post_thumbnail('small');  ?>
    			<?php else: ?>
    				<img src="<?php echo get_template_directory_uri(); ?>/images/default.png" />	
     			<?php endif; ?>
            
			<div class="post_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a> <?php _e('-'); echo get_post_status( get_the_ID() ); ?></div> 
			<div id="list_time"><?php the_time( 'j M, Y' ); ?></div>
			<div id="list_head">
			    <a href="<?php echo $url5.'?page=edit_post&post_id='.$postid; ?>"><?php _e('Edit'); ?></a><?php _e(' | '); ?><a href="<?php the_permalink(); ?>"><?php _e('View'); ?></a><?php _e(' | '); ?><a href="<?php echo $trash_del ?>"><?php _e('Trash'); ?></a>
			</div>
    	</li><!-- .item-list -->
   	<?php endwhile;?>
      	</ul>
      	<?php echo '<div class="pagination">'; if ($wp_query->max_num_pages > 1){echo '<div class="wp-pagenav">'; if(function_exists('pagenavi')) { pagenavi(); } echo '</div>'; }  echo '</div>'; ?>
	<?php else: ?>
		<div align="center" class="no-result">
		    <p><?php _e('No posts found in Pending','tie'); ?></p>
		</div>
	<?php endif; wp_reset_query(); ?>
	</div><!-- .post_list /-->
	</div>
		
<?php }elseif($_GET['post_status'] == "trash"){ ?>
	
	<?php global $wpdb;
		$options1 = get_option('ln_options1'); 
		$url5 = $options1["plink_dash"]; 
		get_header();
	?>
	<div id="block">
	
	<div id="adnan-menu">
    	<h1>All Post | <a href="<?php echo $url5.'?page=new_post'; ?>">Add New Post</a></h1>
	
	<div class="breadcumbs"><?php
	    $user_id = get_current_user_id();
		$publish = PostCount($user_id, 'publish');
		$pending = PostCount($user_id, 'pending');
		$draft = PostCount($user_id, 'draft');
		$trash = PostCount($user_id, 'trash');
		$all = $publish + $pending + $draft + $trash;?>
		    <a href='<?php echo $url5.'?post_status=all'; ?>'><?php _e('All'); ?><?php if ($all > 0){ ?> <span class='count'>(<?php echo $all; ?>)</span><?php } ?></a> <?php _e('|'); ?> 
			<a href='<?php echo $url5.'?post_status=publish'; ?>'><?php _e('Published'); ?><?php if ($publish > 0){ ?> <span class='count'>(<?php echo $publish; ?>)</span><?php } ?></a> <?php _e('|'); ?> 
			<a href='<?php echo $url5.'?post_status=draft'; ?>'><?php _e('Draft'); ?><?php if ($draft > 0){ ?> <span class='count'>(<?php echo $draft; ?>)</span><?php } ?></a> <?php _e('|'); ?>
			<a href='<?php echo $url5.'?post_status=pending'; ?>'><?php _e('Pending'); ?><?php if ($pending > 0){ ?> <span class='count'>(<?php echo $pending; ?>)</span><?php } ?></a> <?php _e('|'); ?>
			<a href="<?php echo $url5.'?post_status=trash'; ?>" class="active"><?php _e('Trash'); ?><?php if ($trash > 0){ ?> <span class='count'>(<?php echo $trash; ?>)</span><?php } ?></a>
	</div></div>
	
	<div id="post-menu">
	<?php $user_id = get_current_user_id();
		$args=array(
		    'post_type' => 'post',
			'post_status' => 'trash',
			'author' => $user_id,
			'numberposts' => -1,
			'posts_per_page' => 15,
			'paged' => get_query_var('paged'));                       
		
		$wp_query = new WP_Query($args);
		if( have_posts() ): echo '<ul class="posts">'; while( have_posts() ): the_post(); 
		
		// Premanent Delete
		$postid = get_the_ID();
		$permanent_wpnonce = esc_html( '_wpnonce=' . wp_create_nonce( "delete-post_$postid" ) );
		$perman_url = home_url( '/' )."wp-admin/post.php?post=$postid";
		$permanent_url = esc_url( $perman_url . "&action=delete&$permanent_wpnonce" );
		
		// Restore from Trash
		$store_wpnonce = esc_html( '_wpnonce=' . wp_create_nonce( "untrash-post_$postid" ) );
		$store_url = home_url( '/' )."wp-admin/post.php?post=$postid";
		$restore_url = esc_url( $store_url . "&action=untrash&$store_wpnonce" );
	?>
		<li>
           
    		    <?php if ( function_exists("has_post_thumbnail") && has_post_thumbnail() ) : ?>	
	     	        <?php the_post_thumbnail('small');  ?>
    			<?php else: ?>
    				<img src="<?php echo get_template_directory_uri(); ?>/images/default.png" />	
     			<?php endif; ?>
			<div class="post_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a> <?php _e('-'); echo get_post_status( get_the_ID() ); ?></div> 
			<div id="list_time"><?php the_time( 'j M, Y' ); ?></div>
			<div id="list_head">
			    <a href="<?php echo $url5.'?page=edit_post&post_id='.$postid; ?>"><?php _e('Edit'); ?></a><?php _e(' | '); ?><a href="<?php the_permalink(); ?>"><?php _e('View'); ?></a>
			</div>
		</li><!-- .item-list -->
   	<?php endwhile;?>
       	</ul>
       		<?php echo '<div class="pagination">'; if ($wp_query->max_num_pages > 1){echo '<div class="wp-pagenav">'; if(function_exists('pagenavi')) { pagenavi(); } echo '</div>'; }  echo '</div>'; ?>
	<?php else: ?>
		<div align="center" class="no-result">
		    <p><?php _e('No posts found in Trash','tie'); ?></p>
		</div>
	<?php endif; wp_reset_query(); ?>
	</div><!-- .post_list /-->
	</div>
		
<?php }else{ ?>
	
	<?php global $wpdb;
		$options1 = get_option('ln_options1'); 
		$url5 = $options1["plink_dash"]; 
		get_header();
	?>
	
	<div id="block">
	
	<div id="adnan-menu">
    	<h1>All Post | <a href="<?php echo $url5.'?page=new_post'; ?>">Add New Post</a></h1>
	
		
	<div class="breadcumbs"><?php
	    $user_id = get_current_user_id();
		$publish = PostCount($user_id, 'publish');
		$pending = PostCount($user_id, 'pending');
		$draft = PostCount($user_id, 'draft');
		$trash = PostCount($user_id, 'trash');
		$all = $publish + $pending + $draft + $trash;?>
		    <a href='<?php echo $url5.'?post_status=all'; ?>' class="active"><?php _e('All'); ?><?php if ($all > 0){ ?> <span class='count'>(<?php echo $all; ?>)</span><?php } ?></a> <?php _e('|'); ?> 
			<a href='<?php echo $url5.'?post_status=publish'; ?>'><?php _e('Published'); ?><?php if ($publish > 0){ ?> <span class='count'>(<?php echo $publish; ?>)</span><?php } ?></a> <?php _e('|'); ?> 
			<a href='<?php echo $url5.'?post_status=draft'; ?>'><?php _e('Draft'); ?><?php if ($draft > 0){ ?> <span class='count'>(<?php echo $draft; ?>)</span><?php } ?></a> <?php _e('|'); ?>
			<a href='<?php echo $url5.'?post_status=pending'; ?>'><?php _e('Pending'); ?><?php if ($pending > 0){ ?> <span class='count'>(<?php echo $pending; ?>)</span><?php } ?></a> <?php _e('|'); ?>
			<a href="<?php echo $url5.'?post_status=trash'; ?>"><?php _e('Trash'); ?><?php if ($trash > 0){ ?> <span class='count'>(<?php echo $trash; ?>)</span><?php } ?></a>
	</div></div>

	<div id="post-menu">
	<?php $user_id = get_current_user_id();
		$args=array(
		    'post_type' => 'post',
			'post_status' => 'publish,pending,draft,trash',
			'author' => $user_id,
			'numberposts' => -1,
			'posts_per_page' => 15,
			'paged' => get_query_var('paged'));                       
		
		$wp_query = new WP_Query($args);
		if( have_posts() ): echo '<ul class="posts">'; while( have_posts() ): the_post(); 
		
		// Move to Trash
		$postid = get_the_ID();
		$trash_wpnonce = esc_html( '_wpnonce=' . wp_create_nonce( "trash-post_$postid" ) );
		$trash_url = home_url( '/' )."wp-admin/post.php?post=$postid";
		$trash_del = esc_url( $trash_url . "&action=trash&$trash_wpnonce" );
		
		// Premanent Delete
		$postid = get_the_ID();
		$permanent_wpnonce = esc_html( '_wpnonce=' . wp_create_nonce( "delete-post_$postid" ) );
		$perman_url = home_url( '/' )."wp-admin/post.php?post=$postid";
		$permanent_url = esc_url( $perman_url . "&action=delete&$permanent_wpnonce" );
		
		// Restore from Trash
		$store_wpnonce = esc_html( '_wpnonce=' . wp_create_nonce( "untrash-post_$postid" ) );
		$store_url = home_url( '/' )."wp-admin/post.php?post=$postid";
		$restore_url = esc_url( $store_url . "&action=untrash&$store_wpnonce" );
	?>
		<li>
            
    		    <?php if ( function_exists("has_post_thumbnail") && has_post_thumbnail() ) : ?>	
	     	        <?php the_post_thumbnail('small');  ?>
    			<?php else: ?>
    				<img src="<?php echo get_template_directory_uri(); ?>/images/default.png" />	
     			<?php endif; ?>
            
			<div class="post_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a> <?php _e('-'); echo get_post_status( get_the_ID() ); ?></div> 
			<div id="list_time"><?php the_time( 'j M, Y' ); ?></div>
			<div id="list_head">
			    <a href="<?php echo $url5.'?page=edit_post&post_id='.$postid; ?>"><?php _e('Edit'); ?></a><?php _e(' | '); ?><a href="<?php the_permalink(); ?>"><?php _e('View'); ?></a><?php _e(' | '); ?><a href="<?php echo $trash_del ?>"><?php _e('Trash'); ?></a>
			</div>
    	</li><!-- .item-list -->
    <?php endwhile;?>
        </ul>
   	<?php echo '<div class="pagination">'; if ($wp_query->max_num_pages > 1){echo '<div class="wp-pagenav">'; if(function_exists('pagenavi')) { pagenavi(); } echo '</div>'; }  echo '</div>'; ?>
	    <?php else: ?>
   	<div align="center" class="no-result">
	    <p><?php _e("You doesn't have any Post.",'tie'); ?></p>
	</div>
	<?php endif; wp_reset_query(); ?>
	</div><!-- .post_list /-->
	</div>	
<?php }
} ?>

<?php get_footer(); ?>