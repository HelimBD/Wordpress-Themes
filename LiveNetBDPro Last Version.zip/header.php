<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes('xhtml'); ?>>
<head>
<title> <?php if ( is_home() ) { ?> <?php bloginfo('title'); ?> | <?php bloginfo('description'); ?> <?php } ?><?php if ( is_single() ) { ?> <?php the_title(); ?> | <?php bloginfo('title'); ?> <?php } ?> <?php if ( is_archive() ) { ?> <?php single_cat_title(); ?> | <?php bloginfo('title'); ?> <?php } ?> <?php if ( is_page() ) { ?> <?php the_title(); ?> | <?php bloginfo('title'); ?> <?php } ?> <?php if ( is_search() ) { ?> Search result for "<?php the_search_query(); ?>" | <?php bloginfo('title'); ?> <?php } ?> <?php if ( is_404() ) { ?> 404 Not Found! - <?php bloginfo('title'); ?> <?php } ?> </title>
<?php include('includes/seo/meta-noindex.php'); ?>
<?php include('includes/extra/scripts.php'); ?>
<?php include_once("includes/seo/analyticstracking.php") ?>
	<link href="<?php echo get_template_directory_uri(); ?>/css/pagenavi-css.css" rel="stylesheet" type="text/css" media="all, handheld" />
	<link href="<?php echo get_template_directory_uri(); ?>/css/dashboard.css" rel="stylesheet" type="text/css" media="all, handheld" />
	<link href="<?php bloginfo( 'template_url' ); ?>/css/style.css" rel="stylesheet" type="text/css" media="all, handheld" />
	<link rel="icon" href="<?php bloginfo( 'template_url' ); ?>/img/favicon.png" type="image/png"/>
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" /> 
<?php wp_head(); ?>
</head>
<body>
<?php include('includes/menu/header-menu.php');?>
<?php include('includes/ad/notice.php');?>
<?php get_template_part('searchform');?>
<script type="text/javascript">
    (function () {
        var options = {
            facebook: "145515516083586", // Facebook page ID
            company_logo_url: "http://livenetbd.ga/wp-content/themes/LiveNetBDMobilePro/img/default.png", // URL of company logo (png, jpg, gif)
            greeting_message: "আসসালামু আলাইকুম, LiveNetBD এ স্বাগতম,আমাদের উদ্দেশ্য একটাই, মানুষকে ভালো কিছু দেওয়া।আমাদের সাইটের প্রতিটি পোস্ট পড়ে দেখুন।ভালো লাগলে আপনার বন্ধুদের সাথে শেয়ার করুন।", // Text of greeting message
            call_to_action: "Message us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-61303738-1', 'auto');
  ga('send', 'pageview');

</script>

<center><img src="http://hnet.yn.lt/add/homepage-ad.png"/></center>



<style>#post-content{  -webkit-animation: fadeInScale 10s ease-in-out;  -moz-animation: fadeInScale 10s ease-in-out;  animation: fadeInScale 0.9s ease-in-out;}

.helimb{  -webkit-animation: fadeInScale 10s ease-in-out;  -moz-animation: fadeInScale 10s ease-in-out;  animation: fadeInScale 0.9s ease-in-out;}
/*Content Animation*/@keyframes fadeInScale {  0% {  	transform: scale(0.9);  	opacity: 0;}}#sponsor-list{margin:4px; background: #fff; border: 1px solid #e1e1e1}#sponsor-list h1{	background: #fff; 	color: #333; 	padding: 12px; 	font-size: 20px;	font-family: "SolaimanLipi", Trebuchet MS;	border-bottom: 1px solid #e1e1e1;}#sponsor-list a{color: #2d6d82; font-family: "Trebuchet MS", SolaimanLipi; font-size: 16px;}#sponsor-list a:hover{color: #444; transition: 2s;}#content-backgrounds{background: #e9ebeb; color: #333; padding: 6px; font-size: 16px;}

.post-menu,.block ul.posts img:hover { transition: all 3s ease; -webkit-transition: all 3s ease;-moz-transition: all 3s ease; transform:rotate(360deg);-moz-transform:rotate(360deg);-webkit-transform:rotate (360deg); position:relative; }

</style>

<style>a {text-decoration: none; color: #444; font-weight: normal;}a:text {text-decoration: none; color: #444; font-weight: normal;}a:link {text-decoration: none; color: #444; font-weight: bold;}a:hover {text-decoration: none; color: #027345;}::-moz-selection {background: #027345;color: #fff; text-shadow: none;}::selection {background: #027345;color: #fff;text-shadow: none;}::-webkit-scrollbar {    width: 8px;}::-webkit-scrollbar-track {    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); }::-webkit-scrollbar-thumb {	background:#027345;}input[type=submit], button{	width: 130px; 	height: 35px; 	padding: 15px 12px; 	background:#027345; 	color: #fff; 	font-weight: bold; 	border: 1px solid #027345; 	font-family: "SolaimanLipi", Arial; 	font-size: 18px; 	padding: 5px;	cursor: pointer;}input[type=text],  input[type=email], input[type=password], input[type=file] {	background: white;  	background-repeat:no-repeat;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );	border:1px solid #ddd; 	font-family: "SolaimanLipi", Arial; 	font-size: 16px;     padding:10px; width: 75%; }input[type=extra-text] {	background: #fff;  	background-repeat:no-repeat;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );	border:1px solid #ddd; 	font-family: "SolaimanLipi", Arial; 	font-size: 16px;     padding:12px; 	width: 90%; 	color: #1b596c;}input[type=search]{	background: white;  	background-repeat:no-repeat;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );	border:1px solid #ddd; 	font-family: "SolaimanLipi", Arial; 	font-size: 16px;     padding:6px; 	width: 90%; }select {	background: white;  	background-repeat:no-repeat;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );	border:1px solid #ddd; 	font-family: "SolaimanLipi", Arial; 	font-size: 17px;     padding:12px; 	width: 79%; }input[type=comment-text]{	background: white;  	background-repeat:no-repeat;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );	border:1px solid #ddd; 	font-family: "SolaimanLipi", Arial; 	font-size: 16px;     padding:16px; 	width: 80.4%; }input[type=subscribe] {	background: white;  	background-repeat:no-repeat;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );	border:1px solid #ddd; 	font-family: "SolaimanLipi", Arial; 	font-size: 16px;     padding:14px; 	width: 70%;	margin: 6px;}textarea{	color: #444; 	background: white; 	width: 81%; 	height: 250px; 	margin: 2px; padding: 4px; 	font-family: "SolaimanLipi", Arial; 	font-size: 16px; 	border: 1px solid #ddd;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );    padding: 13px;    margin-bottom: 20px;}select:focus,textarea:focus,input[type=text]:focus,  input[type=email]:focus, input[type=password]:focus, input[type=file]:focus,input[type=search]:focus,input[type=email]:focus, input[type=extra-text]:focus, input[type=subscribe]:focus,input[type=comment-text]:focus,	.ap-form-wrapper textarea:focus, .ap-form-wrapper input[type=text]:focus, .ap-form-wrapper input[type=email]:focus,.ap-form-wrapper input[type=name]:focus,#page_block input[type=text]:focus,#page_block input[type=email]:focus{	box-shadow: 0;	border: 1px solid #027345;	color: #444;	outline: none;}#page_block input[type=text], #page_block input[type=email]{	background: white;  	background-repeat:no-repeat;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );	border:1px solid #ddd; 	font-family: "SolaimanLipi", Arial; 	font-size: 16px;     padding:14px; 	width: 75%; }	.ap-form-wrapper input[type=text], .ap-form-wrapper input[type=email],.ap-form-wrapper input[type=name]{	background: white;  	background-repeat:no-repeat;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );	border:1px solid #ddd; 	font-family: "SolaimanLipi", Arial; 	font-size: 16px;     padding:14px; 	width: 75%; }.ap-form-wrapper textarea{	color: #444; 	background: white; 	width: 75%; 	height: 250px; 	margin: 2px; padding: 4px; 	font-family: "SolaimanLipi", Arial; 	font-size: 16px; 	border: 1px solid #ddd;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );    padding: 13px;}	.ap-form-field input[type=file] {	background: white;  	background-repeat:no-repeat;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );	border:1px solid #ddd; 	font-family: "SolaimanLipi", Arial; 	font-size: 16px;     padding: 12px; 	width: 75%; }	#login-form input[type=text],#login-form input[type=password]{	background: #fff;  	background-repeat:no-repeat;	box-shadow: inset 0px 20px 30px rgba( 0,0,0,0.1 );	border:1px solid #ddd; 	font-family: "SolaimanLipi", Arial; 	color: #027345;	padding:14px; 	font-size: 15px;	width: 30%;}	#login-form button,#login-form input[type=submit]{	width: 80px; 	height: 35px; 	padding: 15px 12px; 	background: #027345; 	color: #fff; 	font-weight: bold; 	font-size: 18px; 	border: 1px solid #027345; 	padding: 5px;	cursor: pointer;}	h3{background:#c7cad0; color: #333; padding: 8px; font-size: 20px;background: -moz-linear-gradient(top, #eeeff2 0%, #c7cad0 100%); background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#eeeff2), color-stop(100%,#c7cad0)); background: -webkit-linear-gradient(top, #eeeff2 0%, #c7cad0 100%); }@media only screen and (max-width: 400px) {.commentmetadata {top: 20px;}.commentlist p{margin-top: 20px;}}

a:link {color: #027345; font-size: 15px; font-family: sans-serif}

a:active {color: red; font-size: 15px; font-family: sans-serif}

a:visited {color: purple; font-size: 12px; text-decoration: bold;  font-family: sans-serif}

</style>