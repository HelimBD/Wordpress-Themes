<?php get_header(); ?>
<div id="block">
<div id="adnan-menu">
	<?php
		if ( isset( $_GET['postcomment'] ) ) :
			if ( have_posts() ) : while ( have_posts() ): the_post();
				comments_template( '/postcomment.php' );
			endwhile; endif;

		else :
	?>

		<?php if ( have_posts() ): while ( have_posts() ): the_post(); ?>

		     <h1><?php the_title(); ?></h1>
		     <div class="breadcumbs">
			<a href="<?php bloginfo('url'); ?>">Home</a> <font color="#ddd">/</font>
			Page <font color="#ddd">/</font>
			<?php the_title(); ?></div>
		     <div class="page-content">
			<?php the_content(); ?>
			<div id="edit" title="Edit Post" alt="Edit Post"><?php edit_post_link('Edit', '<p>', '<p>'); ?></div>
			</div>
<?php endwhile; ?>
<?php endif;?>
<?php endif; ?></div></div>
<?php get_template_part(sidebar);?>  
<?php get_footer(); ?>