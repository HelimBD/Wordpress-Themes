<div id="block" class="archive_blok"><h1>Newsletter</h1>
<div id="subscribe">
<img alt="LiveNetBD.Ga" title="LiveNetBD.Ga"  src="http://helimbd.yn.lt/up_down_look.gif"/>
<div id="subscribe-text">সবার আগে আমাদের নতুন নতুন সকল আপডেট পেতে আপনার ই-মেইলে সাবস্ক্রাইব করুন</div>
<form action="https://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('http://livenetbd.ga/', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">
<input name="email" type="text" placeholder="Email Address..." value="" required="required"><input name="uri" type="hidden" value="livenetbdga"><input name="loc" type="hidden" value="en_US">
<input type="submit" value="Submit"></form></div></div>