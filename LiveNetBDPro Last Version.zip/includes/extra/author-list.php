<!--Top Authors-->
<div id="top_author"><div id="block" class="category_blok">
<h1>Top Writer's</h1>
<?php
global $wpdb;
$top_authors = $wpdb->get_results("
	SELECT u.ID, count(post_author) as posts FROM {$wpdb->posts} as p
	LEFT JOIN {$wpdb->users} as u ON p.post_author = u.ID
	WHERE p.post_status = 'publish'
	AND p.post_type = 'post'
	GROUP by p.post_author
	ORDER by posts DESC
	LIMIT 0,10
");
if( !empty( $top_authors ) ) {
	echo '<ul>';
	foreach( $top_authors as $key => $author ) {
		echo '<li><a href="' . get_author_posts_url( $author->ID ) . '">' . get_avatar( $author->ID , 50 ) . ' ' . get_the_author_meta( 'display_name' , $author->ID ) . '</a><br/>Total Post:
			<rr>(' . $author->posts . ') </rr>
		</li>';
	}
	echo '</ul>';
}
?></div></div>