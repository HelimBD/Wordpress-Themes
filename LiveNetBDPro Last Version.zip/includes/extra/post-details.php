<div style="border:1px solid #eeeeed; margin:3px; padding-top:2px;"><div style="max-height:200px;overflow:hidden;position:relative; bottom:-1px;"><div id="tit" style="padding:10px"><b id="b"><font color="black"><a href="<?php echo home_url() ?>">Home</a> <font color="#ddd">/</font>
	<?php the_category(', '); ?> <font color="#ddd">/</font> <?php the_title(); ?> </font></b>
<div name="cdtn"><span id="cda"><font color="black"><p id="p-author"></p><?php the_author_meta( 'display_name' ); ?> › <?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?></font></span></div></div>
<span name="fix"><span name="themethumb" id="themsthumb"><center><?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail ('single',array("class" => "feauture_image1"));
}
else {
	echo '<img class="feauture_image" alt="LiveNetBD.Ga" title="LiveNetBD.Ga" src="' . get_bloginfo( 'template_url' ) . '/images/no-thumbnail.png"/>';
} ?></center></span></span>
</div></div>