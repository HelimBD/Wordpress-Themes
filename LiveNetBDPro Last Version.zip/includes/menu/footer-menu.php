

<div class="block" id="footer-menu">
	<li><a title="About us" href="http://livenetbd.ga/about-us/">About us</a></li>
	<li><a title="User Rights" href="http://livenetbd.ga/user-rights/">User Rights</a></li>
	<li><a title="Terms of use" href="http://livenetbd.ga/terms-of-use/">Terms of Use</a></li>
	<li><a title="Privacy Policy" href="http://livenetbd.ga/privacy-policy/">Privacy Policy</a></li>
	<li><a title="Copyright Issues" href="http://livenetbd.ga/copyright-issues/">Copyright Issues</a></li>
   <?php if ( is_user_logged_in() ){ ?>		<li><a href="<?php echo wp_logout_url( home_url() ); ?>"><?php global $current_user;
        get_currentuserinfo();
		echo 'Logout (' . $current_user->user_login."\n"; echo ')'; ?></a></li>
	<?php } ?>
 </div>
 

 