<div id="block" class="list_blok">
<h1>Sponsored Sites</h1><ul>
<li><i id='i-arrow'></i><a target="blink" href="https://www.intelwhitehost.com/"><font color="black">Domain & Hosting Service</font></a></li>
<li><i id='i-arrow'></i><a target="blink" href="http://www.icchabazar.com/"><font color="purple">Online Shop</font></a></li>
<li><i id='i-arrow'></i><a target="blink" href="http://wap4dollar.com/ad/serve.php?id=vilhatuip9"><font color="green">Earn Money Online</font></a></li>
<li><i id='i-arrow'></i><a target="blink" href="https://www.intelwhitehost.com/"><font color="#d50304">Free Nid Card Generator</font></a></li>
<li><i id='i-arrow'></i><a target="blink" href="http://livenetbd.ga/wp-favorite-posts/"><font color="skyblue">Your Favrate Post</font></a></li>
</ul></div>

<div id="block" class="list_blok">
<h1>Support Link</h1><ul>
<li><i id="i-arrow"></i><a target="blink" href="https://www.facebook.com/helim.rana12">Admin on Facebook</a></li>
<li><i id="i-arrow"></i><a target="blink" href="https://facebook.com/helimbd.ga">Facebook Official Page</a></li>
<li><i id="i-arrow"></i><a target="blink" href="https://facebook.com/groups/allwapkamasterbd">Facebook Official Group</a></li>
</ul></div>