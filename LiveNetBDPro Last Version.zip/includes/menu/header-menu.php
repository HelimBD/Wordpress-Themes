<?php global $wpdb;
$options1 = get_option('ln_options1'); 
$options2 = get_option('wpc_pages'); 
$url5 = $options1["plink_dash"]; 
$redirected_ul = $url5;
$url = $options2["users"]; 
$url2 = $options2["messaging"]; 
$crnt = get_current_user_id();
?>
	
<?php if ( is_user_logged_in() ){ ?>	

<div class="block_top_menu">
	<ul class="menu" >
	    <li><a href="<?php echo $url5; ?>">Dashboard</a></li>
		<li><a href="<?php echo home_url(); ?>/author/<?php echo get_the_author_meta('user_login',wp_get_current_user()->ID); ?>">Profile</a></li>
		<li><a href="<?php echo $url5.'?page=new_post'; ?>">New Post</a></li>
	</ul>
</div>
<?php } ?>


<table id="header" width="100%"><tbody><tr><td><center><h1><a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo( 'template_url' ); ?>/img/logo.png" /></a></h1></center>
</td></tr></tbody></table>



			<?php if (is_user_logged_in()){ ?>
				<div id="q-menu">
<a title="Home" class="home" href="<?php echo home_url(); ?>">Home</a>
	<?php echo do_shortcode('[f_notification var="user" out="ntc_l_count"]'); ?>
</div>
				
			<?php }else{ ?>
				<div id="q-menu">
<a title="Home" href="/">Home</a>
<a title="Login" href="/wp-login.php?redirect_to=/">Login</a> 
<a title="Register" href="/wp-login.php?action=register">Register</a>  
<a title="Submit Your Post" href="http://livenetbd.ga/submit-post/">Submit Your Post</a>
</div>
			<?php } ?>
		
		<center><font size="5px"><script src="http://helimbd.yn.lt/files/welcome.js"></script></font></center>
		<style>
		.block_top_menu{overflow: hidden;background: #23282D; }
.block_top_menu ul{list-style: none; background: #23282D; }
.block_top_menu ul li{text-align: center; width: 33.33333333333%; background: #4c4cdd; float:left; background: #337ab7;}
.block_top_menu ul li:hover{background: #4444B3; }
.block_top_menu ul li a{padding: 5px 0px; color: #bdc1c9; display:block; font-family: verdana;}
.block_top_menu ul li a:hover{text-decoration: none}

/* Header CSS*/#header {background:#018c53; padding: 8px; background:-webkit-gradient(linear, 0 0, 0 100%, from(#018c53), to(#018c53));}#header h1 img{width: 180px; height: 40px; margin-left: 8px; margin-top: 8px; margin-bottom: 1px;}#header h1 img {max-width: 99%;height: auto;width: auto\9;}#header h2 img{max-width: 99%;height: auto;width: auto\9;}#header {margin: 0;padding: 10px 20px;text-decoration :none;overflow :hidden;}#header a {color :#fff;font-weight: bold;overflow :hidden;text-decoration :none;text-shadow: 0 1px 1px #333;width :100%;}#header {margin: 0;font-size: 12px;overflow: hidden;padding: 0 6px 4px;font-weight: normal;width :100%;}#header h1{font-size: 30px; font-weight: bold;}#header h2{font-size: 14px; color: white; font-weight: normal;}

		/* Quick Menu CSS*/#q-menu{background: #027345; color: #fff; padding: 9px;}#q-menu a{color: #fff; border-right: 1px solid #211B1A; padding-right: 7px; padding-left: 7px;}#q-menu a:last-child{border-right: none;}#q-menu2{background: #333; color: #fff; padding: 9px;}#q-menu2 a{color: #fff; border-right: 1px solid #000; padding-right: 7px; padding-left: 7px;}#q-menu2 a:last-child{border-right: none;}/* Additional CSS*/#adnan-menu ul li img{max-width: auto;}#adnan-menu ul img{max-width: auto;}#adnan-menu li img{max-width: auto;}
		
		.block_top_menu{overflow: hidden;background: #23282D; }
.block_top_menu ul{list-style: none; background: #23282D; }
.block_top_menu ul li{text-align: center; width: 33.33333333333%; background: #4c4cdd; float:left; background: #337ab7;}
.block_top_menu ul li:hover{background: #4444B3; }
.block_top_menu ul li a{padding: 5px 0px; color: #bdc1c9; display:block; font-family: verdana;}
.block_top_menu ul li a:hover{text-decoration: none}</style>