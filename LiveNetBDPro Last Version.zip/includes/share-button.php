<!--Post Share Button-->
<div style="padding-top: 4px; padding-bottom: 6px" class="post-sharing">
<a target="_blink" title="Share on Facebook" class="facebook" href="https://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&t=<?php the_title(); ?>" data-action="share/facebook/"><font color="white">Facebook</font></a> 

<a target="_blink" title="Share on Twitter" class="twitter" href="https://twitter.com/intent/tweet?text=<?php the_permalink(); ?>&t=<?php the_title(); ?>" data-action="share/twitter/"><font color="white">Twitter</font></a> 

<a target="_blink" title="Share on Google+" class="google" href="https://plus.google.com/share?url=<?php the_permalink(); ?>&t=<?php the_title(); ?>" data-action="share/google+/"><font color="white"> Google+</font></a> 
 
<a title="Share on Message" class="message" href="sms:+88?body=<?php the_title(); ?> | Read now - <?php bloginfo('url'); ?>" data-action="share/message/"> <font color="white">Message</font></a> 

<a title="Share on Whatsapp" class="whatsapp" href="whatsapp://send?text=<?php the_title(); ?> | Read Now - <?php bloginfo('url'); ?>" data-action="share/whatsapp/"> <font color="white">Whatsapp</font></a> 

<a title="Share on Viber" class="viber" href="viber://forward?text=<?php the_title(); ?> | Read now - <?php bloginfo('url'); ?>" data-action="share/viber/"> <font color="white">Viber</font></a>
</div></div> <font color="white">