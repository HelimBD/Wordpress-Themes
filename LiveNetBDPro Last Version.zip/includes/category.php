<div id="block" class="category_blok">
<h1>প্রাত্যহিক আয়োজন</h1>
<ul>
<li><i id="i-cate"></i><a title="আজকের এই দিনে" href="/?cat=8"> আজকের এই দিনে
<r><?php echo wp_get_cat_postcount(8); ?></r></a></li>
<li><i id="i-cate"></i><a title="আজকের রাশিফল" href="/?cat=9"> আজকের রাশিফল
<r><?php echo wp_get_cat_postcount(9); ?></r></a></li>
<li><i id="i-cate"></i><a title="টিভির সময়সূচী" href="/?cat=7"> টিভির সময়সূচী
<r><?php echo wp_get_cat_postcount(7); ?></r></a></li>
	<h1>সাহিত্য কেটাগোরি</h1>
<li><i id="i-cate"></i><a title="ইসলামিক শিক্ষা" href="/?cat=3"> ইসলামিক শিক্ষা
<r><?php echo wp_get_cat_postcount(3); ?></r></a></li>
<li><i id="i-cate"></i><a title="ইসলামিক জ্ঞান" href="/?cat=5"> ইসলামিক জ্ঞান
<r><?php echo wp_get_cat_postcount(5); ?></r></a></li>
<li><i id="i-cate"></i><a title="ইসলামিক সংবাদ " href="/?cat=4"> ইসলামিক সংবাদ 
<r><?php echo wp_get_cat_postcount(4); ?></r></a></li>
<li><i id="i-cate"></i><a title="ইসলামিক ঘটনা" href="/?cat=6"> ইসলামিক ঘটনা
<r><?php echo wp_get_cat_postcount(6); ?></r></a></li>
<li><i id="i-cate"></i><a title="বাংলা কৌতুক" href="/?cat=28"> বাংলা কৌতুক
<r><?php echo wp_get_cat_postcount(28); ?></r></a></li>
<li><i id="i-cate"></i><a title="১৮+ কৌতুক" href="/?cat=29"> ১৮+ কৌতুক
<r><?php echo wp_get_cat_postcount(29); ?></r></a></li>
<li><i id="i-cate"></i><a title="বাংলা ধাধা" href="/?cat=54">বাংলা ধাধা
<r><?php echo wp_get_cat_postcount(54); ?></r></a></li>
<li><i id="i-cate"></i><a title="জানা অজানা" href="/?cat=30"> জানা অজানা
<r><?php echo wp_get_cat_postcount(30); ?></r></a></li>
	<li><i id="i-cate"></i><a title="অন্যান্য" href="/?cat=1"> অন্যান্য
<r><?php echo wp_get_cat_postcount(1); ?></r></a></li>
	<h1>টিপ্স এন্ড ট্রিক্স </h1>
<li><i id="i-cate"></i><a title="কম্পিউটার টিপস" href="/?cat=22"> কম্পিউটার টিপস
<r><?php echo wp_get_cat_postcount(22); ?></r></a></li>
<li><i id="i-cate"></i><a title="মোবাইল টিপস" href="/?cat=21"> মোবাইল টিপস
<r><?php echo wp_get_cat_postcount(21); ?></r></a></li>
<li><i id="i-cate"></i><a title="ফেসবুক টিপস" href="/?cat=20"> ফেসবুক টিপস
<r><?php echo wp_get_cat_postcount(20); ?></r></a></li>
<li><i id="i-cate"></i><a title="রূপচর্চা/বিউটি-টিপস" href="/?cat=15"> রূপচর্চা/বিউটি-টিপস
<r><?php echo wp_get_cat_postcount(15); ?></r></a></li>
<li><i id="i-cate"></i><a title="সাস্থ্যকথা/হেলথ-টিপস" href="/?cat=14"> সাস্থ্যকথা/হেলথ-টিপস
<r><?php echo wp_get_cat_postcount(14); ?></r></a></li>
<li><i id="i-cate"></i><a title="লাইফ স্টাইল" href="/?cat=16"> লাইফ স্টাইল
<r><?php echo wp_get_cat_postcount(16); ?></r></a></li>
<li><i id="i-cate"></i><a title="সাজগোজ টিপস" href="/?cat=19"> সাজগোজ টিপস
<r><?php echo wp_get_cat_postcount(19); ?></r></a></li>
<li><i id="i-cate"></i><a title="রেসিপি টিপস" href="/?cat=17"> রেসিপি টিপস
<r><?php echo wp_get_cat_postcount(17); ?></r></a></li>
<li><i id="i-cate"></i><a title="টুকিটাকি টিপস" href="/?cat=18"> টুকিটাকি টিপস
<r><?php echo wp_get_cat_postcount(18); ?></r></a></li>
	<h1>রিভিউ সমগ্র</h1>
<li><i id="i-cate"></i><a title="এপস রিভিউ" href="/?cat=26"> এপস রিভিউ
<r><?php echo wp_get_cat_postcount(26); ?></r></a></li>
<li><i id="i-cate"></i><a title="গেমস রিভিউ" href="/?cat=27"> গেমস রিভিউ
<r><?php echo wp_get_cat_postcount(27); ?></r></a></li>
<li><i id="i-cate"></i><a title="মোবাইল ফোন রিভিউ" href="/?cat=25"> মোবাইল ফোন রিভিউ
<r><?php echo wp_get_cat_postcount(25); ?></r></a></li>
	<h1>বিনোদন ডেস্ক</h1>
<li><i id="i-cate"></i><a title="নাটক ও টেলিফিল্ম" href="/?cat=12"> নাটক ও টেলিফিল্ম
<r><?php echo wp_get_cat_postcount(12); ?></r></a></li>
<li><i id="i-cate"></i><a title="বিবিধ বিনোদন" href="/?cat=11"> বিবিধ বিনোদন
<r><?php echo wp_get_cat_postcount(11); ?></r></a></li>
<li><i id="i-cate"></i><a title="মিউজিক ক্যাফে" href="/?cat=13"> মিউজিক ক্যাফে
<r><?php echo wp_get_cat_postcount(13); ?></r></a></li>
<li><i id="i-cate"></i><a title="সিনেমা জগৎ" href="/?cat=10"> সিনেমা জগৎ
<r><?php echo wp_get_cat_postcount(10); ?></r></a></li>
	<h1>বিজ্ঞান ও প্রযুক্তি</h1>
<li><i id="i-cate"></i><a title="নতুন প্রযুক্তি" href="/?cat=23"> নতুন প্রযুক্তি
<r><?php echo wp_get_cat_postcount(23); ?></r></a></li>
<li><i id="i-cate"></i><a title="ইন্টারনেট দুনিয়া" href="/?cat=24"> ইন্টারনেট দুনিয়া
<r><?php echo wp_get_cat_postcount(24); ?></r></a></li>
<li><i id="i-cate"></i><a title="বিবিধ টেক" href="/?cat=47"> বিবিধ টেক
<r><?php echo wp_get_cat_postcount(47); ?></r></a></li>
	<h1>অপরেটর নিউজ</h1>
<li><i id="i-cate"></i><a title="গ্রামীনফোন" href="/?cat=42">  গ্রামীনফোন
<r><?php echo wp_get_cat_postcount(42); ?></r></a></li>
<li><i id="i-cate"></i><a title="বাংলালিংক" href="/?cat=41"> বাংলালিংক
<r><?php echo wp_get_cat_postcount(41); ?></r></a></li>
<li><i id="i-cate"></i><a title="রবি/একটেল" href="/?cat=43"> রবি/একটেল
<r><?php echo wp_get_cat_postcount(43); ?></r></a></li>
<li><i id="i-cate"></i><a title="এয়ারটেল" href="/?cat=44"> এয়ারটেল
<r><?php echo wp_get_cat_postcount(44); ?></r></a></li>
<li><i id="i-cate"></i><a title="টেলিটক" href="/?cat=45"> টেলিটক
<r><?php echo wp_get_cat_postcount(45); ?></r></a></li>
	<h1>ওয়েবমাস্টার</h1>
<li><i id="i-cate"></i><a title="ওয়াপকা" href="/?cat=40"> ওয়াপকা
<r><?php echo wp_get_cat_postcount(40); ?></r></a></li>
<li><i id="i-cate"></i><a title="ওয়ার্ডপ্রেস" href="/?cat=39"> ওয়ার্ডপ্রেস
<r><?php echo wp_get_cat_postcount(39); ?></r></a></li>
<li><i id="i-cate"></i><a title="JavaScript" href="/?cat=386">JavaScript
<r><?php echo wp_get_cat_postcount(386); ?></r></a></li>
<li><i id="i-cate"></i><a title="Our Notice" href="/?cat=386">Our Notice
<r><?php echo wp_get_cat_postcount(386); ?></r></a></li>
	<h1>হট জোন</h1>
<li><i id="i-cate"></i><a title="বাংলা চটি" href=http://livenetbd.wapka.mobi/forum2_113190088.xhtml">বাংলা চটি
<r>500+</r></a></li>

<ul>
</div>
<style>

.category_blok ul.a:hover{color: #027345;}

r {border: 1px solid gray; background: #027345; padding: 1px 2px;color: white; float: right; text-shadow: none;}</style>