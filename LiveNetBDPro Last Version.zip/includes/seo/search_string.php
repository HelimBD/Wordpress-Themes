<!--Search String-->
<script type="application/ld+json">
{
   "@context": "http://schema.org",
   "@type": "WebSite",
   "url": "http://livenetbd.ga",
   "potentialAction": {
   "@type": "SearchAction",
   "target": "http://livenetbd.ga/?s=",
   "query-input": "Search Tunes"
   }
}
</script>

<!--Business Links-->
<script type="application/ld+json">
    {
    "@context": "http://schema.org",
    "@type": "Organization",
    "name" : "LiveNetBD.Ga",
    "url": "http://livenetbd.ga",
    "sameAs" : [
    "https://www.facebook.com/helimbd.ga"
    ]
    }
</script>

<!--Business Address-->
<script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "LocalBusiness",
      "name" : "LiveNetBD.Ga",
      "url": "http://livenetbd.ga",
      "logo": "http://livenetbd.ga/wp-content/plugins/mobilepress/themes/default/screenshot.png",
      "description": "LiveNetBD.Ga is a Public islamic Forum based on Islamic Sariah. about Islamic knowledge, Islamic life style, al-quran, hajj, jakat, salat, islamic stories and more islamic content includes.",
  "telephone": "+88 01983446721",
"address": {
    "@type": "PostalAddress",
    "addressLocality": "Gazipur, Bangladesh",
    "addressRegion": "ON",
    "streetAddress": "Gazipur, Bangladesh"
  },
  "openingHours": [
    "Mo-Fr 09:00-17:00"
  ]
  }
</script>