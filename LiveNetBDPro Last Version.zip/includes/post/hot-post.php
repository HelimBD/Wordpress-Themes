<div id="block"><div id="post-menu">
 <h1>Hot Tunes</h1><div class="block">
	<ul class="posts">
	<?php function filter_where($where = '') {
		//posts in the last 3 days
		$where .= " AND post_date > '" . date('Y-m-d', strtotime('-3 days')) . "'";
		return $where;
	}
	add_filter('posts_where', 'filter_where');
	
	query_posts('post_type=post&posts_per_page=4&meta_key=post_views_count&orderby=meta_value_num&order=DESC');
	if (have_posts()) : while (have_posts()): the_post(); ?>
   <li>
<?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'thumbnail' );
}
else {
	echo '<img width="150" height="150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="LiveNetBD.Ga" title="LiveNetBD.Ga" src="' . get_bloginfo( 'template_url' ) . '/images/default.png"/>';
} ?>
<div class="post_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" accesskey="<?php echo $access_key; $access_key++; ?>"><?php the_title(); ?></a></div>
<font color="#000"><p id="p-author"></p><span><?php the_author_meta( 'display_name' ); ?></span> <font color="#eeeeed">|</font><p id="p-times"></p><span><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?></span> <font color="#eeeeed">|</font> <p id="p-views"></p><span> <?php echo getPostViews(get_the_ID()); ?></span></font>  <font color="#eeeeed">|</font> <p id="p-comments"></p><span> <?php comments_popup_link( 'No Comments' , '1 Comment' , '% Comments' ); ?></span></font>
<div class="pc_content">
<div style="color: #444;" class="post-content"><?php echo wp_trim_words( get_the_content(),20, '...'); ?>
</div></div>
</li>
<?php endwhile; else: ?>
<?php endif; ?>
	<?php wp_reset_query(); ?> 
</ul>
</div></div></div>

<style>.block ul.posts img {float: left;padding: 1px;max-width: 99%;   height: auto;width: auto\9;border: 1px solid #ddd;margin-right: 6px;border-radius: 50%;width: 70px;height: 70px;}
</style>