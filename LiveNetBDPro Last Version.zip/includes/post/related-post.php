<div id="block">
<div id="post-menu">
<h1>Related Posts</h1><div class="block">
<ul class="posts">
<?php
	$category = get_the_category(); //get first current category ID
	$this_post = $post->ID; // get ID of current post
	$posts = get_posts('numberposts=6&category=' . $category[0]->cat_ID . '&exclude=' . $this_post);
	foreach($posts as $post) { ?>
<li>
<?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'thumbnail' );
}
else {
	echo '<img width="150" height="150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="LiveNetBD.Ga" title="LiveNetBD.Ga" src="' . get_bloginfo( 'template_url' ) . '/images/default.png"/>';
} ?>
<div class="post_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" accesskey="<?php echo $access_key; $access_key++; ?>"><?php the_title(); ?></a></div>
<font color="#000"><p id="p-author"></p><span><?php the_author_meta( 'display_name' ); ?></span> <font color="#eeeeed">|</font><p id="p-times"></p><span><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?></span> <font color="#eeeeed">|</font> <p id="p-views"></p><span> <?php echo getPostViews(get_the_ID()); ?></span></font>
</li>
<?php } wp_reset_postdata(); ?>
</ul>
</div></div></div>
<style>.block ul.posts img {float: left;padding: 1px;max-width: 99%;   height: auto;width: auto\9;border: 1px solid #ddd;margin-right: 6px;border-radius: 50%;width: 70px;height: 70px;}

 .block ul.posts img:hover { transition: all 3s ease; -webkit-transition: all 3s ease;-moz-transition: all 3s ease; transform:rotate(360deg);-moz-transform:rotate(360deg);-webkit-transform:rotate (360deg); position:relative; }

</style>