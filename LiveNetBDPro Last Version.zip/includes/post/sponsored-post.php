<div id="block">
<div id="post-menu"><h1>Wordpress Themes</h1><div class="block">
	<ul class="posts"><div class="figure">
	    	<li><img width="60" height="36" src="http://helimbd.yn.lt/images/Capture.JPG" class="featured_image wp-post-image" alt="" srcset="http://helimbd.yn.lt/images/Capture.JPG" sizes="(max-width: 60px) 100vw, 60px" />		<h2 class="title"><a href="http://wap4dollar.com/refer.php?refer=vilhatuip9">IslamPriyo Mobile Themes Share By Helim Hasan Akash</b></a> </h2>
			<p class="t_a_meta"><p id="p-author"></p><font color="green"><span>Helim Hasan Akash</span> </font> <p id="p-times"></p><font color="red"><span>Jan 23, 2018</span> </font> <p id="p-views"></p><span>990 Views</span>
</p>
			
		</li>
	    	<li><img width="60" height="60" src="http://helimbd.yn.lt/images/Capturedddddddddddd.JPG" class="featured_image wp-post-image" alt="" srcset="http://helimbd.yn.lt/images/Capturedddddddddddd.JPG" sizes="(max-width: 60px) 100vw, 60px" />		<h2 class="title"><a href="http://wap4dollar.com/ad/serve.php?id=vilhatuip9"><b>AmarTips Mobile Version Themes Free Download</b></a> </h2>
			<p class="t_a_meta"><p id="p-author"></p><font color="green"><span>SohagSrz</span> </font> <p id="p-times"></p><font color="red"><span>Jan 22, 2018</span> </font> <p id="p-views"></p><span>853 Views</span>
</p>
			
		</li>
	    	
		 
</div></ul>
</div></div></div>










<div id="block">
<div id="post-menu">
    <h1>Featured post</h1>
	<ul class="posts">
	<?php $args = array(
     	'post_type' => 'post',
		'showposts' => 1,
		'tax_query' => array(
		'relation' => 'OR',
    		array(
			'taxonomy' => 'category',
			'field' => 'slug',
			'terms' => array('Aside'),),
			array(
			'relation' => 'AND',
			array(
		    'taxonomy' => 'post_format',
			'field' => 'slug',
			'terms' => array('post-format-Aside'),),),),
		);
		$catquery = new WP_Query($args);
		$thumbnail = get_template_directory_uri()."/images/default.png"; 
        	if ($catquery->have_posts()) : while ($catquery->have_posts()) : $catquery->the_post(); ?>
          <li>
<?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'thumbnail' );
}
else {
	echo '<img width="150" height="150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="LiveNetBD.Ga" title="LiveNetBD.Ga" src="' . get_bloginfo( 'template_url' ) . '/images/default.png"/>';
} ?>
<div class="post_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" accesskey="<?php echo $access_key; $access_key++; ?>"><?php the_title(); ?></a></div>
<font color="#000"><p id="p-author"></p><span><?php the_author_meta( 'display_name' ); ?></span> <font color="#eeeeed">|</font><p id="p-times"></p><span><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?></span> <font color="#eeeeed">|</font> <p id="p-views"></p><span> <?php echo getPostViews(get_the_ID()); ?></span></font>  <font color="#eeeeed">|</font> <p id="p-comments"></p><span> <?php comments_popup_link( 'No Comments' , '1 Comment' , '% Comments' ); ?></span></font>
<div class="">
<div style="color: #444;" class="post-content"><?php echo wp_trim_words( get_the_content(),20, '...'); ?>
</div></div>
</li>
<?php endwhile; else: ?>
<?php endif; ?>
		<?php wp_reset_query(); ?> 
	</ul>
</div></div>