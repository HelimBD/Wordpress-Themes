<div id="block">
<div id="post-menu"><h1>Choti Post</h1><div class="block">
	<ul class="posts"><div class="figure">
	    	<li><img width="60" height="36" src="https://i0.wp.com/www.banglachoticlub.com/wp-content/uploads/2018/03/Bangla-Choti-Golpo-2018.jpg?w=543&ssl=1" class="featured_image wp-post-image" alt="" srcset="https://i0.wp.com/www.banglachoticlub.com/wp-content/uploads/2018/03/Bangla-Choti-Golpo-2018.jpg?w=543&ssl=1" sizes="(max-width: 60px) 100vw, 60px" />		<h2 class="title"><a href="http://livenetbd.wapka.mobi/forum2_113190088.xhtml">দয়া করে ১৮ বছরের নিছে কেও ভিসিট করবেন না।</b></a> </h2>
			<p class="t_a_meta"><p id="p-author"></p><font color="green"><span>ChotiWap</span> </font> <p id="p-times"></p><font color="red"><span>Jan 23, 2018</span> </font> <p id="p-views"></p><span>1125 Views</span> <div style="color: #444;" class="post-content">শম্পা বৌদি আমার চেয়ে উচ্চ পদে প্রতিষ্ঠিত আধিকারিক অর্থাৎ আমার বসের স্ত্রী, তাই তার দিকে এগুনোর অর্থ হল নিজের চাকরি খোওয়ানোর ব্যাবস্থা করা, তাই শত ইচ্ছে থাকা সত্বেও বৌদির যৌবনকে শুধু দৃষ্টি ভোগ করা ছাড়া আমার আর কোনও উপায় ছিল না।</div>
</p>
			
		</li>
	    	<li><img width="60" height="60" src="https://i2.wp.com/www.banglachoticlub.com/wp-content/uploads/2018/03/DOI2NQ5V4AAiwUn.jpg?resize=768%2C1024&ssl=1" class="featured_image wp-post-image" alt="" srcset="https://i2.wp.com/www.banglachoticlub.com/wp-content/uploads/2018/03/DOI2NQ5V4AAiwUn.jpg?resize=768%2C1024&ssl=1" sizes="(max-width: 60px) 100vw, 60px" />		<h2 class="title"><a href="http://livenetbd.wapka.mobi/forum2_113190088.xhtml"><b>দয়া করে ১৮ বছরের নিছে কেও ভিসিট করবেন না।</b></a> </h2>
			<p class="t_a_meta"><p id="p-author"></p><font color="green"><span>Choti Wap</span> </font> <p id="p-times"></p><font color="red"><span>Jan 22, 2018</span> </font> <p id="p-views"></p><span>1153 Views</span><div style="color: #444;" class="post-content">
সেইরাতে আমি ঘুমাতে পারিনি। আমার চোখের সামনে বৌদির মাইয়ের খাঁজটা বারবার ভেসে উঠছিল। যার ফলে বৌদির কথা ভাবতে ভাবতে আমায় খেঁচে মাল ফেলতে হয়ে ছিল।</div>
</p>
			
		</li>
	    	
		 
</div></ul>
</div></div></div>




<div id="block">
<div id="post-menu">
<h1>Recent Posts</h1><div class="block">
<ul class="posts">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<li>
<?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'thumbnail' );
}
else {
	echo '<img width="150" height="150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="LiveNetBD.Ga" title="LiveNetBD.Ga" src="' . get_bloginfo( 'template_url' ) . '/images/default.png"/>';
} ?>
<div class="post_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" accesskey="<?php echo $access_key; $access_key++; ?>"><?php the_title(); ?></a></div>
<font color="#000"><p id="p-author"></p><span><?php the_author_meta( 'display_name' ); ?></span> <font color="#eeeeed">|</font><p id="p-times"></p><span><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?></span> <font color="#eeeeed">|</font> <p id="p-views"></p><span> <?php echo getPostViews(get_the_ID()); ?></span><div class="pc_content"><font color="#eeeeed">|</font> <p id="p-comments"></p><span> <?php comments_popup_link( 'No Comments' , '1 Comment' , '% Comments' ); ?></span>
</div></font>
<div class="pc_content">
<div style="color: #444;" class="post-content"><?php echo wp_trim_words( get_the_content(),20, '...'); ?>
</div></div>
</li>
<?php endwhile; else: ?>
<?php endif; ?>
</ul></div></div>
<!--Pagination-->
<?php if ($wp_query->max_num_pages > 1) get_template_part('navigation') ;?>
<div class="clearfix"></div></div>


<style>.block ul.posts img {float: left;padding: 1px;max-width: 99%;   height: auto;width: auto\9;border: 1px solid #ddd;margin-right: 6px;border-radius: 50%;width: 70px;height: 70px;}
</style>