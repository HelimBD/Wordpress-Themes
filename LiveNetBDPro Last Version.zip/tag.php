<?php get_header(); ?>
<div id="block">
<div id="post-menu">
<h1>Keyword Related Post</h1>
<div class="breadcumbs">
<a href="<?php bloginfo('url'); ?>">Home</a> <font color="#ddd">/</font> 
<span class="current">Tags for "<?php single_tag_title(); ?>"</span></div>
<ul class="posts">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<li>
<?php
// Feature post thumbnail.

if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'thumbnail' );
}
else {
	echo '<img width="150" height="150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="LiveNetBD.Ga" title="LiveNetBD.Ga" src="' . get_bloginfo( 'template_url' ) . '/images/default.png"/>';
} ?>
<div class="post_title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" accesskey="<?php echo $access_key; $access_key++; ?>"><?php the_title(); ?></a></div>
<font color="#000"><p id="p-author"></p><span><?php the_author_meta( 'display_name' ); ?></span> <font color="#eeeeed">|</font><p id="p-times"></p><span><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?></span> <font color="#eeeeed">|</font> <p id="p-views"></p><span> <?php echo getPostViews(get_the_ID()); ?></span></font>
<div class="pc_content">
<div style="color: #444;" class="post-content"><?php echo wp_trim_words( get_the_content(),20, '...'); ?>
</div></div>
</li>
<?php endwhile; else: ?>
<?php endif; ?>
</ul>
</div></div>

<?php get_template_part(sidebar);?> 
<?php get_footer(); ?>