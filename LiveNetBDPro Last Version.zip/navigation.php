<font color="black"><div class=""><div class="wp-pagenav"><center><div class=""><?php wp_pagenavi(); ?></div></center></div></div></font>




 
   
   <style>.paging {margin: 0px; font-size: 0px; }
.paging a {font-weight:normal; color: black; display: inline-block;
background: #fff; border: 1px solid #08a0db; margin: 2px; padding: 3px 5px; font-size: 15px; text-decoration: none; }
.paging b, .paging a:hover {color: white; display: inline-block; background: #08a0db; margin: 2px;
padding: 3px 5px; font-size: 15px;font-weight:normal}</style>