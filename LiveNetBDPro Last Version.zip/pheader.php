<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes('xhtml'); ?>>
<head>
<title> <?php if ( is_home() ) { ?> <?php bloginfo('title'); ?> | <?php bloginfo('description'); ?> <?php } ?><?php if ( is_single() ) { ?> <?php the_title(); ?> | <?php bloginfo('title'); ?> <?php } ?> <?php if ( is_archive() ) { ?> <?php single_cat_title(); ?> | <?php bloginfo('title'); ?> <?php } ?> <?php if ( is_page() ) { ?> <?php the_title(); ?> | <?php bloginfo('title'); ?> <?php } ?> <?php if ( is_search() ) { ?> Search result for "<?php the_search_query(); ?>" | <?php bloginfo('title'); ?> <?php } ?> <?php if ( is_404() ) { ?> 404 Not Found! - <?php bloginfo('title'); ?> <?php } ?> </title>
<?php include('includes/seo/meta-noindex.php'); ?>
<?php include('includes/extra/scripts.php'); ?>
<?php include_once("includes/seo/analyticstracking.php") ?>
	<link href="<?php echo get_template_directory_uri(); ?>/css/pagenavi-css.css" rel="stylesheet" type="text/css" media="all, handheld" />
	<link href="<?php echo get_template_directory_uri(); ?>/css/dashboard.css" rel="stylesheet" type="text/css" media="all, handheld" />
	<link href="<?php bloginfo( 'template_url' ); ?>/css/style.css" rel="stylesheet" type="text/css" media="all, handheld" />
	<link rel="icon" href="<?php bloginfo( 'template_url' ); ?>/img/favicon.png" type="image/png"/>
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" /> 
<?php wp_head(); ?>
</head>
<body>
<?php include('includes/menu/header-menu.php');?>
<?php include('includes/ad/notice.php');?>