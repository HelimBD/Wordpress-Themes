<div id="search-form">
    <form method="get" action="<?php bloginfo( 'home' ); ?>">
<input type="text" class="inp-text" name="s" placeholder="Search Topics..." value="" required="required"><input type="submit" value="Search"></form></div>