<?php get_template_part(iheader); ?>
<div id="post-content">
<?php include('includes/post/sponsored-post.php'); ?>
<?php include('includes/post/hot-post.php'); ?>
<?php include('includes/post/index-post.php'); ?></div>

<div id="post-content">
<?php get_template_part('includes/category'); ?>
<?php get_template_part('includes/menu/list-menu'); ?>

<?php get_template_part('includes/extra/newsletter'); ?></div>
<?php get_template_part(sidebar);?>
<?php get_footer(); ?>
